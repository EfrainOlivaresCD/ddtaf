import os.path
from xml.sax import saxutils
from xml.sax import make_parser
from xml.sax.handler import feature_namespaces

class ETFSettingsParser(saxutils.DefaultHandler):
    def __init__(self, pSettings):
        self.settings = pSettings
        self.comserver = {}
        
    def startElement(self, name, attrs):
        if name == "COMServer":
            self.comserver = {}
            self.comserver["progid"] = str(attrs.getValue("progid"))
            self.comserver["namespace"] = str(attrs.getValue("namespace"))
            
    def endElement(self, name):
        if name == "COMServers":
            self.settings.comservers.append(self.comserver)
            self.comserver = {}
   
class ETFSettings:
    def __init__(self):
        # contains a list of 
        # [{'progid': 'TestCOM2.MyClass', 'namespace': '', ...]
        self.comservers = []
        self.loaded = False
        self.file = "ETFSettings.xml"
        
    def load(self, pFile):
        # Create a parser
        parser = make_parser()
    
        # Tell the parser we are not interested in XML namespaces
        parser.setFeature(feature_namespaces, 0)
    
        # Create the handler
        dh = ETFSettingsParser(self)
    
        # Tell the parser to use our handler
        parser.setContentHandler(dh)
    
        # Parse the input
        parser.parse(pFile)        
        
    def quickLoad(self):
        if self.loaded == False:
            self.loaded = True
            self.load(self.file)                        
        
    def getCOMServers(self):
        self.quickLoad()
        return self.comservers

if __name__ == '__main__':
    # Create a parser
    parser = make_parser()

    # Tell the parser we are not interested in XML namespaces
    parser.setFeature(feature_namespaces, 0)

    se = ETFSettings()
    # Create the handler
    dh = ETFSettingsParser(se)

    # Tell the parser to use our handler
    parser.setContentHandler(dh)

    # Parse the input
    parser.parse("ETFSettings.xml")
    
    print se.comservers
    
    # Short way ... 
    se = ETFSettings()
    print se.getCOMServers()
    print __file__, os.path.dirname(__file__)
