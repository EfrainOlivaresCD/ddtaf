import pythoncom
import win32com.client.dynamic
import win32api
import win32con
import pywintypes
import logging

from handler.Handler import Handler_Base
from interface.IHandler import IHandlerComponent
from handler.ETF.ETFSettings import ETFSettings

class ETF_Handler_Registry(IHandlerComponent):
    def __init__(self):
        self._dispatcher = None
        self.logger = logging.getLogger('Handler.ETF')
    
    def start(self):
        # create an handler object for each COM server
        se = ETFSettings()
        for comserver in se.getCOMServers():
            # support namspaces
            namespace = comserver["namespace"]
            if namespace == "":
                handler = Execute('ExecuteETF')
            else:
                handler = Execute('ExecuteETF.' + namespace)
            handler.setPROGID(comserver["progid"]) 
            self.logger.debug('registered handler name:%s progid:%s' % ('ExecuteETF.' + comserver["namespace"], comserver["progid"]))   
            self._dispatcher.register_handler(handler)
    
    def setDispatcher(self, pDispatcher):
        self._dispatcher = pDispatcher

class Execute(Handler_Base):
    def setPROGID(self, pProgid):
        self.progid = pProgid
        
    def getFunctionName(self, Command):
        return Command.getItem('function').split("(")[0]
    
    def Execute(self, Command):
            #return 'Fail'
        self.progid = self.progid # "TestCOM2.MyClass" # "TestCOM2.MyClass" #"NanoScope.zApi"
        print "JO", Command.getItem('action'), Command.getItem('function'), Command.getItem('data'), self.getFunctionName(Command)
        if hasattr(self, "dispatch") == False:
            self.dispatch = win32com.client.dynamic.Dispatch(self.progid) #, clsctx = pythoncom.CLSCTX_LOCAL_SERVER)
        ret = getattr(self.dispatch, self.getFunctionName(Command))(*eval(Command.getItem('data')))
        print ret
        #TODO: replace eval with parser
        #print getattr(self.dispatch, Command.object[0]), ret , (eval(Command.data))
#        if eval("ret" + Command.passeval) == True:
 #           return "Pass"
  #      return "Fail"        
        return 'Pass'
