from interface.IHandler import IHandler
import logging

class Handler_Base(IHandler):
    def __init__(self, key):
        self.logger = logging.getLogger('handler.python.Handler_Base')
        self.key = key
        
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        return 'Pass'
        
    def Execute(self, pTestStep):
        return 'Pass'
        
    def getKey(self):
        return self.key
        
    def setKey(self, key):
        self.key = key