import pythoncom
import win32com.client.dynamic
import win32api
import win32con
import pywintypes
import logging

from handler.Handler import Handler_Base
from interface.IHandler import IHandlerComponent
from handler.ETF.ETFSettings import ETFSettings

class SimFW_Handler_Registry(IHandlerComponent):
    def __init__(self):
        self._dispatcher = None
        self.logger = logging.getLogger('Handler.SimFW')
    
    def start(self):
        # create an handler object for each COM server
        handler = SimFWPublish('SimFWPublish')
        handler.setPROGID("Python.COMMessageServer") 
        self.logger.debug('registered handler progid: Python.COMMessageServer')   
        self._dispatcher.register_handler(handler)
    
    def setDispatcher(self, pDispatcher):
        self._dispatcher = pDispatcher

class SimFWPublish(Handler_Base):
    def setPROGID(self, pProgid):
        self.progid = pProgid
        
    def Execute(self, Command):
        #return 'Fail'
        self.progid = self.progid
        try:
            if hasattr(self, "dispatch") == False:
                self.dispatch = win32com.client.dynamic.Dispatch(self.progid) #, clsctx = pythoncom.CLSCTX_LOCAL_SERVER)
            params = "('" + Command.getItem('object').split("(")[0] + "',\"" + Command.getItem('data') + "\")"
            ret = getattr(self.dispatch, "publish")(*eval(params))
        except pywintypes.com_error:
            return 'Fail'
        return 'Pass'
