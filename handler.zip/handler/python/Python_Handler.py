import smtplib
import os, string, re
import time, win32gui
import logging
import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
from email import Encoders


from handler.Handler import Handler_Base
from common.screencapture import captureWindow
from common import winGuiAuto
from common.Utility import Utility
from common import ProcessInformation
from message import DDTAFEvent
from interface.IHandler import IHandlerComponent
from xmlSettings import Settings 

class Python_Handler_Registry(IHandlerComponent):
    def __init__(self):
        self._dispatcher = None
    
    def start(self):
        #Python DDTAF internal Handlers
        self._dispatcher.register_handler(checkApp('checkapp'))
        self._dispatcher.register_handler(tearDown('killprocess'))
        self._dispatcher.register_handler(LaunchApp('launch'))
        self._dispatcher.register_handler(DDTAF_ScreenCapture('screenshot'))
        self._dispatcher.register_handler(DDTAF_Click('lclick'))
        self._dispatcher.register_handler(Wait('wait'))
        self._dispatcher.register_handler(MailTo('mailto'))
        self._dispatcher.register_handler(FailLine('failline'))
        self._dispatcher.register_handler(InvalidHandler('invalid_handler_handler'))
    
    def setDispatcher(self, pDispatcher):
        self._dispatcher = pDispatcher

################################################################################      
class Python_Handler_Base(Handler_Base):
  def Pre_Execute(self,pTestStep,bGenerateCode = True):
      return 'Ok'
      
  #function to determine if a process is running 
  def isAlive(self, processName):
    #Lower case, and split extension off.
    processName = string.strip(processName.lower())
    processNameNoext = processName.lower().split('.')[0]

    proclist = ProcessInformation.getRunningModules()
    proclist = [string.strip(n.lower()) for n in proclist]
    if proclist.count(processName) or proclist.count(processNameNoext):
      return True      
    #Print out only if error:
    self.logger.error('Process NOT Found %s or %s'%(processName, processNameNoext) )
    return False 

################################################################################      
class LaunchApp(Python_Handler_Base):

  def Execute(self, pTestStep, pTestCase):
      appname = pTestStep.getItem('window')
      process = pTestStep.getItem('data').split(',')
      process = [string.strip(n.lower()) for n in process]
      success = 'Pass'
      for p in process:
        if self.isAlive(p):
          success = 'Fail'
          print 'Can not launch.  Another process, %s is open' %p
      if success == 'Fail':
          return 'Fail'
      se = Settings()
      se.quickLoad()
      for p in process:
          directory = se.getPaths().get(p)
          if directory == None:
              print 'Launch App Error: Can not find path for key %s'%p
              return 'Fail'
          directory = directory.lower()
          #filter out the option such as -r -db
          mainProcess = p.lower()
          mainProcess = re.sub(' ', '', mainProcess)
          if re.match(".*%s" % (mainProcess), directory):
              directoryNoOption = re.match(".*%s"%(mainProcess), directory).group()
          else:
              print 'Error: Launch path %s does not include %s'%(directory, mainProcess)
              return 'Fail'
          
          #get the options
          options = re.sub(".*%s"%(mainProcess),'',directory)
          
          try:
             if not os.path.isfile(directoryNoOption):
                  print 'Launch target not found %s'%(directoryNoOption)
                  return 'Fail'          
          except :
              print "The process could not be launched, %s, %s"%(directory, mainProcess)
              return 'Fail'
              
          #os.system() Cannot use this..it doesnt return right away
          #os.startfile() Cannot use this..cannot pass env
          print options
          os.spawnv(os.P_NOWAIT,directoryNoOption, [directoryNoOption, options ])
          
          #Do we have time for short nap?  
          time.sleep(3.0)
          
          #did we really succeed?  or did os.sapwnv just lie?
          if self.isAlive(mainProcess):
              success = 'Pass'
          else:
              return 'Fail'
      return success
          
###############################################################################      
class checkApp(Python_Handler_Base):          
  def IsRunning(self, app, window, notText=None):
    if (self.isAlive(app)):
      if (self.isWindowOpen(window, notText)): #and self.isWindowOpen("Debug")):
        return True
      else:
        print 'Can not find Window %s'%(window)
        return False
    print 'Can Not Find %s Process'%(app)
    return False
  
  def Execute(self, com, pTestCase):   
      appname = com.getItem('window')
      obj = com.getItem('object').split('/')
      process = com.getItem('data').split(',')
      process = [string.strip(n.lower()) for n in process]
      
      is_up = False
      for i in range(0, len(process)):
        if self.isAlive(process[i]):
          is_up = True
      
      #If is_up is False, then neither process is up so were not running.
      if is_up != True:
        return 'Fail'
      
      winText = obj[0]
      notText = None
      #remove ! from exclude part of object
      if len(obj) >= 2:
            obj[1] = re.sub('!', '', obj[1])
            notText = obj[1]
          
      if self.IsRunning(process[0], winText, notText):
          return 'Pass'
      else:
          return 'Fail'
  
  def MyCallback( self, hwnd, extra ):
      extra.append(hwnd)
  
  def isWindowOpen(self, caption, notThis=None):
      caption = caption.lower()
      if notThis:
          notThis = notThis.lower()
          
      result = False
      numWindows = 0
      windows = []
      winDict = {}
      windowsText=[]
      j = 0
      win32gui.EnumWindows(self.MyCallback, windows)
      for i in windows:
          if win32gui.IsWindowVisible(i): 
              if win32gui.IsWindowVisible:
                  windowsText.append(i)
                  winDict[numWindows] = i
                  numWindows +=1
      #print 'windowsText: ' + str(windowsText)
      for window in windowsText:
          windowText = win32gui.GetWindowText(window)
          windowText = windowText.lower()
          if re.match('.*'+caption+'.*', windowText):
              if notThis:
                  if not re.match('.*'+notThis+'.*', windowText):
                      result = True
              else:
                  result = True
          #print j, windowText
          j += 1
      return result
      
################################################################################      
class tearDown(Python_Handler_Base):    
  def kill(self, processName):
    if not self.isAlive(processName):
        return True
    count = 0
    while(self.isAlive(processName)and count<10):
        try:
            ProcessInformation.killprocid(ProcessInformation.getprocid(processName))
            time.sleep(1)
            count += 1
        except:
            return self.isAlive(processName)
    #Give it a second to check again.
    time.sleep(1)
    
    if not self.isAlive(processName):
      return True
    else:
      return False
    
  def Execute(self, pTestStep, pTestCase):
    data = pTestStep.getItem('data').split(',')
    data = [n.lower().strip() for n in data]
    success = 'Pass'
    for i in range(0, len(data)):
        if not self.kill(data[i]):
            success = 'Fail'
    
    return success
################################################################################      
class DDTAF_ScreenCapture(Python_Handler_Base):
    def Pre_Execute(self, com, bGenerateCode = True):
        win = com.getItem('window')
        obj = com.getItem('object').split('/')
        data = str(com.getItem('data'))
        #  obj[0]     /     obj[1]
        #  windowText /  ! excludeText
        #Thus first character in excludeText must be ! or else throw Error.
        if len(obj) >= 2:
            if obj[1][0] != '!':
                print 'ERROR: DDTAF_ScreenCapture, syntax. Exptected window/!exclude got %s'% obj
                return 'Error'
            else:
                re.sub('!', '', obj[1])
            
        #make sure we have a name for screen capture
        if data == 'none':
            print 'No Name for Screen Capture at line ' + com.getItem('line')
            return 'Error'
        return 'Ok'

    
    def Execute(self, com, pTestCase):
        win = com.getItem('window')
        obj = com.getItem('object').split('/')
        data = com.getItem('data')
        
        winText = obj[0]
        notText = None
        #remove ! from exclude part of object
        if len(obj) >= 2:
            obj[1] = re.sub('!', '', obj[1])
            notText = obj[1]
        
        #Modify data field to include time stamp for name
        data = re.sub('"','',data)#remove quotes
        data = re.sub(' ','',data)#remove spaces
        timeStamp = time.strftime("%m%d%H%M%S", time.localtime(time.time()))
        filename = data + '_' + timeStamp + '.png'
        #Put this in command object so report shows name too, report 
        #maker will need to use this.
        com.setItem("data", filename)
        #Now save the name to screens directory
        image = captureWindow(winText, notText)
        
        if image == None:
            time.sleep(5.0)
            print 'Retry ScreenShot'
            image = captureWindow(winText, notText)
            
        if image == None:
            print 'ERROR: Python Screen Capture Failed'
            return 'Fail'
            
        #now build location to drop it off.
      
        filePath = com.getParameter('screenspath') + '\\' + filename
        try:            
            image.save(filePath)
        except:
            print 'ERROR Can not find file %s'%(filePath)
            return 'Fail'
        return 'Pass'

################################################################################      
class DDTAF_Click(Python_Handler_Base):
    def Pre_Execute(self, com, bGenerateCode = True):
        win = com.getItem('window')
        obj = com.getItem('object').split('/')
        
        if len(obj) > 1:
            print 'ERROR: Single Name %s only for Click on button'%(obj)
            return 'Error'
        return 'Ok'
    
    def Execute(self, com, pTestCase):
        win = com.getItem('window')
        obj = com.getItem('object').split('/')
        data = com.getItem('data')
        
        #changed to only one retry because it takes to damn long...
        for tries in range(1, 2):
            #If it's a button in a window...simple level only    
            if winGuiAuto.PressButton( win, obj[0] ) == 'Fail':
                #print 'Waiting 5 seconds for retry # %s'%(tries)
                time.sleep(5.0)
            else:
                #return immediately if passed
                return 'Pass'
            
        #For last retry    
        if winGuiAuto.PressButton( win, obj[0] ) == 'Fail':
                return 'Fail'
        else:
                return 'Pass'
        
class Wait(Python_Handler_Base):
    def Pre_Execute(self, com, bGenerateCode =True):
        data = re.sub('[sS]','',com.getItem('data'))
        if ( not (Utility().isConvertableToFloat(data))):
            print 'ERROR in Wait.Execute: Cannot understand data column input: ' + data
            return 'Error'
        seconds = float(data)
        if seconds < 0:
            print 'ERROR in Wait.Execute: We cannot travel back in time, please choose a positive number: ' + data
            return 'Error'                        
        return "Ok"
        
    def Execute(self, pTestStep, pTestCase):
        data = re.sub('[sS]','',pTestStep.getItem('data'))
        if ( not (Utility().isConvertableToFloat(data))):
            print 'ERROR in Wait.Execute: Cannot understand data column input: ' + data
            return 'Fail'
        seconds = float(data)
        if seconds < 0:
            print 'ERROR in Wait.Execute: We cannot travel back in time, please choose a positive number: ' + data
            return 'Fail'
        #set the waiting event to true
        DDTAFEvent().setEventState("ddtaf_is_awake", False)
        #msg.isAwake.clear()
        
        #msg.time = seconds
        #Then take a nap!
        print 'Sleeping for %s seconds'%(seconds)
        time.sleep(seconds)
        DDTAFEvent().setEventState("ddtaf_is_awake", True)
        #msg.isAwake.set()
        
        return 'Pass'

class MailTo(Python_Handler_Base):
    def Execute(self, pTestStep, pTestCase):
        server = pTestStep.getItem('window')
        target = pTestStep.getItem('object')
        text = pTestStep.getItem('data') 
        if len(text) == 0:
            print 'No text found.  Exiting MailTo handler'
            return 'Fail'
        filePath = ""
        #if the variable calls for suite, suck it up and put it in 'text'
        try:
            #if text indicates a key name
            if text[0] == '$':
                text = re.sub('\$', '', text)
                reportPath = pTestStep.getParameter('reportpath')
                filePath = ''
                if text[0] == '#':
                    filename = pTestStep.getParameter(re.sub("[$_#]", "", text))
                    if filename == None:
                        print "No file name found for the key: ", text
                        raise
                    filePath = '%s\\Main%s.html'%(reportPath,filename)
            #else text is real path
            else:
                filePath = text
        except:
                print "Failed to send an email to ", pTestStep.getItem("object")
                return 'Fail'                        
       
        try:
            subject = "DDTAF2: Automated Report"
            fro = "DDTAF <ddtaf@veeco.com>"
            to = pTestStep.getItem("object")
            msg = MIMEMultipart()
            msg['From'] = fro
            msg['To'] = to
            msg['Date'] = formatdate(localtime=True)
            msg['Subject'] = subject
            f = open(filePath,"r")
            msg.attach(MIMEText(f.read(),"html"))
            f.close()                                                   
            server = smtplib.SMTP(server)
            server.sendmail('ddtaf@veeco.com', target, msg.as_string())
            server.quit()
            return 'Pass'
        except:
            print 'ERROR Could not send mail to %s'%(target)
            return 'Fail'
   
               
                                   

class FailLine(Python_Handler_Base):
    def Execute(self, pTestStep, pTestCase):
        print 'Fail Line on Purpose'
        return 'Fail'

class InvalidHandler(Python_Handler_Base):
    def Pre_Execute(self, com, bGenerateCode = True):
        print 'ERROR: Invalid Handler'
        return 'Error'
        
    def Execute(self, pTestStep, pTestCase):
        print '**Invalid Action Handler Calling User Abort to exit**'
        print '**Run Sanity Check before running again**'
        DDTAFEvent().setEventState("is_test_aborted", True)
        return 'Fail'