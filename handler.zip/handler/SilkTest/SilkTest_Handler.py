import os, sys, re
import time
import shutil
import logging
import string

#from database import Tables
from database.Tables import Path
from common.Utility import Utility
from message import DDTAFEvent
import message
from interface.IHandler import IHandlerComponent, IHandler

def GetCurrentTime():
#Generate time stamp after each test
        Time=time.asctime()
        return Time

class SilkTest_Handler_Base(IHandler):
    def __init__(self, key):
        self.key = key
        
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
       return 'Pass'
     
    def Execute(self, pTestStep, pTestCase):
        return 'Pass'
        
    def getKey(self):
        return self.key
        
    def setKey(self, key):
        self.key = key
   
    def setDatabase(self,_DB):
        pass
    

class Test_Pass(SilkTest_Handler_Base):
    def Execute(self, pTestStep, pTestCase):
        return 'Pass'
        
class Test_Fail(SilkTest_Handler_Base):
    def Execute(self, pTestStep, pTestCase):
        return 'Fail'
        
class SilkTest_Handler_Registry(IHandlerComponent):
    def __init__(self):
        self._dispatcher = None
        self.logger = logging.getLogger('')
    
    def start(self):
        self.logger.debug('start silktest component')
        self.path = Path()
        self.path.startDatabase()
        objectList = [Click('click'), Select('select'),RClick('rclick'), Popup_Select('popupselect'),
                      Enter('enter'),Close('close'),Q_Equals('?equals'),Q_EqualsApprox('?equals,+/-%'),
                      Q_Focus('?focus'),Q_Status('?status'),Q_Focus('?checked'),Remember('remember'),
                      ScreenShot('screencapture'),Q_Closed('?closed'),DbClick('dbclick'),Focus('focus'),
                      Q_Exists('?exists'),Click('check'),Q_Focus('?pressed'),Open_Nanoscope('opennanoscope'),
                      Drag('drag'),ClickHold('click&hold'),PressKey('presskey'),EndTest('endtest'),
                      Left_Popup_Select('lpopupselect'),Test_Pass('passline'),Test_Fail('failline'),Minimize('minimize'),
                      Press_Key('presskey')]
                      
        #Register handlers
        #Set database
        for object in objectList:
            object.setDatabase(self.path)
            self._dispatcher.register_handler(object)
            
      
    def setDispatcher(self, pDispatcher):
        self._dispatcher = pDispatcher     
    
    def stop(self):
        self.path.stopDatabase()   
    
class SilkTest_Handler(SilkTest_Handler_Base):
    def __init__(self, key):
        self.U = Utility()
        self.logger = logging.getLogger('DefaultLogger')
        self.key = key
        #SilkTest_Handler_Base.__init__(self , key)
        #self.path = Map.Map('v624a')
        self.PathCmd = []
        self.WinPath = []
        #self.path = Tables.Path() 
        self.OnePath = ''
        #newObjectTypes 
        self.Button2 = 'bu'
        self.Window2 = 'wd'
        self.StatusBar2 = 'sb'
        self.MenuMenuMenu2 = 'mumumu'
        self.MenuMenu2 = 'mumu'
        self.Menu2 = 'mu'
        self.ListPullDown2 = 'lipd'
        self.ListTab2 = 'lita'
        self.RadioButton2 = 'rb'
        self.Tab2 = 'ta'
        self.WindowItem2 = 'wi'
        self.TextField2 = 'tx'
        self.TreeNodeMenuMenu2 = 'trndmumu'
        self.TreeNode2 = 'trnd'
        self.PullDown2 = 'pd'
        self.List2 = 'li'
        self.CheckBox2 = 'cb' 
        self.Table2 = 'ti'
        self.TitleBar2 = 'tb' 
        self.Node2 = 'nd'
        self.SlideBar2 = 'sl'
        self.TreeNodeNodeNode2 = 'trndndnd'
        self.TreeNodeNode2 = 'trndnd'
        self.ListRadioButton2 = 'lirb'
        self.TreeNodeMenu2 = 'trndmu'
        self.Icon2 = 'ic'
        self.Error2 = 'Error'
        self.Null2 = 'nullnull'
        self.ListText2 = 'litx'
        self.Tree2 = 'tr'
        self.LeftArrow2 = 'leftarrow'
        self.RightArrow2 = 'rightarrow'
        self.TreeMenu2 = 'trmu'
        self.TreeNodeNodeMenu2= 'trndndmu'
        self.ListMenu2 = 'limu'
        self.TreeMenuMenu2 = 'trmumu'
        self.TreeNodeNodeNodeNode2 = 'trndndndnd'
        self.TreeNodeNodeNodeNodeNode2 = 'trndndndndnd'
        self.TreeNodeNodeNodeNodeNodeNode2 = 'trndndndndndnd'
        self.TreeNodeNodeNodeNodeNodeNodeNode2 = 'trndndndndndndnd'
        self.ButtonMenu2 = 'bumu'      
        self.debug = 0
        self.path = None
        self.SilkCmd = ''
    
    def Pre_Execute(self, pTestStep, bGenerateCode=True):
        self.setData(pTestStep)
        #self.path.setVersion(pTestStep.getParameter('version'))
   
    def setDatabase(self, _DB):
        self.path = _DB     
    
    def setData(self, pTestStep):
        _str = str(pTestStep.getItem('data'))
        if _str !=None:
            #TODO: Do not remove white space  
            keyMarker = ['#', '##']
            for m in keyMarker:
                if _str.find(m) != -1:
                    _str = re.sub(' ','',_str)
                    type, key = self.parseKey(_str)
                    rt = pTestStep.getParameter(key)
                    #replace #key to the value that you got
                    if rt!=None:
                        _str = re.sub(key, str(rt),_str)
                    pTestStep.setItem('data', _str)
                   
                    
    
    def getKeyName(self, _str):
        if _str.find("#")!=-1:
            p = re.compile("\#\w+") #match to a word after # character
            m = p.search(_str)
            keyName = m.group()
            return keyName
        else:
            return None
    
    def parseKey(self, _str):
        type = ''
        data = ''
        typeList = ['not', '%', '>', '<']
        for a in typeList:
            if _str.find(a) != -1:
                key = _str.lstrip(a)
                type = a
                data = self.getKeyName(_str)
                return type , data
        return None, self.getKeyName(_str)                
    
        
    def Execute(self, command, pTestCase):
        testname = command.getParameter('testname')
        testname = self.U.removeKnownExtensions(testname)
        
        baseFilename = testname + '_' + re.sub('\.','_',command.getItem('line').getStr())
       
        self.logger.debug("executing %s" % baseFilename)
        
        # change to partner for SilkTest or runtime for SilkTest Runtime
        if self.type == "SilkTest":
            command_string = 'partner -resextract -r -q ' + baseFilename + '.t'
        else:
            command_string = 'runtime -resextract -r -q ' + baseFilename + '.t'
        #print command.getItem('line') + ' ' + command.getItem('window') + pTestStep.getItem('object').split('/') + ' ' + command.getAction() + ' ' + self.QueryData(pTestStep)
        DDTAFEvent().setEventState("is_silk_done", False)
#        print command_string
#        print os.popen(command_string)  
        os.system(command_string)
        DDTAFEvent().setEventState("is_silk_done", True)
        time.sleep(1)
        FileNotFound = True
        count = 0
        #AButton = AbortButton.AbortButton()
        while(FileNotFound):
            #if AButton.Abort():
            if message.isAbort():
                return 'Fail'
                
            if(count > 5):
                FileNotFound = False
                return 'Fail'
                print command.getItem('line') + '- RESULT FILE NOT FOUND'
            try:
                input = open(baseFilename + '.txt','r')
                FileNotFound = False
                line = input.readline()
                if(line.find('Script ' + baseFilename + '.t - Passed') >= 0):
                    return 'Pass'
                else:
                    print input.read()
                    return 'Fail'
                input.close()
            except IOError:
                time.sleep(3)
                count += 1
        
    def GenerateCode(self, pTestStep, SilkCmd, Window, BoolRetVal, ActiveTry=False):
        #Generates a Silktest file for each line of code in the excel file
        #print 'HANDLER MAKES: ' + pTestStep.getTestName() + '_' + re.sub('\.','_',pTestStep.getItem('line')) + '.t'
        testname = pTestStep.getParameter('testname')
        testname = self.U.removeKnownExtensions(testname)
        
        FileBase = testname + '_' + re.sub('\.','_',pTestStep.getItem('line').getStr())
        output = open(FileBase + '.t','w')
        #print 'CREATE FILE %s'%pTestStep.setParameter('testnameandline')
        output.write('testcase '+ FileBase+ '()\n{\n')
        if ActiveTry:
            output.write('  SetActiveTry(' + Window + ');\n')
        else:
            output.write('  SetActive(' + Window + ');\n')
        if(BoolRetVal):
            output.write('  if(!(' + SilkCmd + '))\n')
            output.write('{\n')
            output.write('reraise;\n')
            output.write('  }\n')
        else:
            output.write(SilkCmd + ';\n')
        output.write('}\n')
        output.close()
        
    def Add_Stars(self, origString):
        editedString = ''
        origString = re.sub(' ' ,'', origString)
        for a in origString:
          editedString += a + '*'
        return editedString
   #only for the path
    def Add_Stars_NotLast(self, origString):
        editedString = ''
        origString = re.sub(' ' ,'', origString)
        count = 1
        length = len(origString)
        for a in origString:
          if count == length:
              return editedString + a
          editedString += a + '*'
          count = count + 1
          
    def extractType(self, line):
        m = re.search('\(\w\w\)', line)
        if m != None:
            result = m.group()
            #print "After grouping :", result
            result = re.sub('[\(\)]', '',result)
            return result
        else:
            return 'Error'

    def returnType(self, ComObject):
        #if it has '\'
        resultString = ''
        if(re.match('.*leftarrow.', ComObject)):
            return 'leftarrow'
        elif(re.match('.*rightarrow.', ComObject)):
            return 'rightarrow'
        elif(re.match('.*/.*', ComObject)):
            objectList = ComObject.split('/')
            for a in objectList:
                #print 'a :', a
                extracted = self.extractType(a)
                if extracted == 'Error':
                    return 'Error'
                else:
                    resultString += extracted
            if self.debug:
                print 'Extracted Type: ', resultString
            return resultString
        elif re.match('nullnull', ComObject):
            return ComObject
        else:
            resultString = self.extractType(ComObject)
            if self.debug:
                print 'Extracted Type: ', resultString
            return resultString
    
    def getObjectPath(self, ObjectType, pTestStep):
        ComObject = pTestStep.getItem('object').split('/')
        Tables_ComObject = pTestStep.getItem('object')
                #return the name of radio button
        if ObjectType in [self.RadioButton2, self.Tab2, self.TextField2, self.PullDown2, self.List2, self.CheckBox2, self.Node2, self.Icon2, self.WindowItem2, self.Button2, self.Window2, self.StatusBar2, self.Icon2, self.SlideBar2 ]:
            return self.Add_Stars(self.cutType(ComObject[0]))
        elif ObjectType in [self.ListPullDown2, self.ListTab2, self.ListRadioButton2, self.ListText2]:
            return (self.Add_Stars(self.cutType(ComObject[0])), self.Add_Stars(self.cutType(ComObject[1])))
        elif ObjectType in [self.Tree2, self.TreeNode2, self.TreeNodeNode2, self.TreeNodeNodeNode2, self.TreeNodeNodeNodeNode2, self.TreeNodeNodeNodeNodeNode2, self.TreeNodeNodeNodeNodeNodeNode2, self.TreeNodeNodeNodeNodeNodeNodeNode2]:
            path = ''
            for object in ComObject:
                path += '/' + self.cutType(object) 
            return self.Add_Stars(path)
        elif ObjectType in [self.MenuMenu2]:
            path = ''
            count = 0
            for object in ComObject:
                if count == 0:
                    path = self.Add_Stars_NotLast(self.cutType(object))
                else:
                    path += '/'+"*"+self.Add_Stars_NotLast(self.cutType(object))
                count = count + 1
            return path
        elif ObjectType in [self.MenuMenuMenu2, self.Menu2]:
            path = ''
            count = 0
            for object in ComObject:
                if count == 0:
                    path = self.cutType(object)
                else:
                    path += '/'+self.cutType(object)
                count = count + 1
            return self.Add_Stars_NotLast(self.cutType(path))
           
        elif ObjectType in [self.ButtonMenu2, self.TreeMenuMenu2, self.ListMenu2, self.TreeMenu2, self.TreeNodeNodeMenu2, self.TreeNodeMenu2, self.TreeNodeMenuMenu2]:
            node = 'NULL'
            path = ''
            count = 0
            for object in ComObject:
                if self.returnType(object)in [self.Node2, self.Tree2]:
                    node = self.cutType(object)
                elif count == 0 and self.returnType(object)== self.Menu2:
                    path = self.cutType(object)
                    count = count + 1
                elif self.returnType(object)== self.Menu2:
                    path += '/'+self.cutType(object)
            if node is not 'NULL':
                node = self.Add_Stars(node)
            return node, self.Add_Stars_NotLast(path)
           
            
        elif ObjectType == self.Table2:
           
            #remove(ti)from (ti)Name(Va1, Va2, Va3)
            str1 = re.sub('^\(\w\w\)','',Tables_ComObject)
            #get table name 
            name = re.sub('\(.*\)','',str1)
            #get values
            #remove(ti)
            values = re.sub('^\(\w\w\)','',Tables_ComObject)
            m = re.search('\(.*\)',values)
            if m != None:
                vals = m.group()
                vals = re.sub('[\(\)]', '' ,vals)
                #split vals
                splitedVals = vals.split(',')
                #return list(name, val1, val2, val3)
                return (name, self.Add_Stars(splitedVals[0]), self.Add_Stars(splitedVals[1]), self.Add_Stars(splitedVals[2]))
            else:
                print 'ERROR in getObjectPath:  Could not find the row, col names.  Returning None'
                return None
                  
        else:
            print 'ERROR in getObjectPath:  Default if case hit.  Returning None'
            return None
           
          # returns the object name without type
    # e.g. "(Bu)Ok" => "Ok"
    def cutType(self, mObject):
        return re.sub('\(\w\w\)', '', mObject)        

    #returns 'Ok' if found command in database, else it returns 'Error'
    def Init_Parser(self, pTestStep):
        i = 0
        TempCmdLine = ''
        self.PathCmd = []
        self.WinPath = []
        if self.path == None:
            self.path = Path()
        self.path.setVersion(pTestStep.getParameter('version'))
        self.type = pTestStep.getParameter('exe_mode')
        self.OnePath = self.path.getPath(pTestStep.getItem('window'), pTestStep.getItem('object'))
        #Parse out the command object
        for Line in pTestStep.getItem('object').split('/'):
            #Concatenate the command objects together
            if(i > 0):
                TempCmdLine += '/'
            TempCmdLine += Line
            Line = re.sub('\(\.*,.*\)','',Line)

            #Get the Path for each command object
            self.PathCmd.append(self.path.getPath(pTestStep.getItem('window'),TempCmdLine))
            if(self.path.getPath(pTestStep.getItem('window'),TempCmdLine).find('NULL') >= 0):
                tempStr = re.sub(' ', '', pTestStep.getItem('window') + TempCmdLine)
                print 'pTestStep ' + pTestStep.getItem('line') + ' ' +  tempStr + ' NOT FOUND IN DATABASE'
                return 'Error'
            i += 1

        self.WinPath = self.path.getPath(pTestStep.getItem('window'),pTestStep.getItem('object').split('/')[0]).split('.')
        pTestStep.setItem('key', pTestStep.getItem('data')) #to resolve the data when it is used as a key
        return 'Ok'

    def Remember(self,pTestStep, bGenerateCode):
         CmdObj = pTestStep.getItem('object')
         SilkCmd = ""
         WinPath = self.OnePath
         ParWin = re.sub('\.\w+\Z','',WinPath)
         ObjectType2 = self.returnType(CmdObj)
         if ObjectType2 in [self.ListText2, self.ListPullDown2]:
             SilkCmd = 'Remember(' + ParWin + ',' + WinPath +', "' + self.getObjectPath(ObjectType2,pTestStep)[0]+'", "'+self.getObjectPath(ObjectType2,pTestStep)[1] + '","NULL","NULL")'
         elif(ObjectType2 == self.Table2):
             lst = self.getObjectPath(ObjectType2, pTestStep)
             SilkCmd += 'Remember(' + ParWin + ',' + WinPath + ', "NULL", "' + lst[2] + '","' + lst[1] + '","' + lst[3] + '")'
         elif(ObjectType2 == self.StatusBar2):
             lst = self.getObjectPath(ObjectType2, pTestStep)
             SilkCmd += 'Remember(' + ParWin + ',' + WinPath + ', "NULL", "NULL", "NULL", "NULL")'
             #Generate the SilkTest File
             self.GenerateCode(pTestStep,SilkCmd,ParWin.split('.')[0],False,True)
             return 'Ok'
         else:
             SilkCmd += 'Remember(' + ParWin + ',' + WinPath + ', "NULL", "' + self.cutType(pTestStep.getItem('object').split('/')[0]) + '","NULL","NULL")'
          
         #Generate the Silktest File
         if bGenerateCode:
             self.GenerateCode(pTestStep,SilkCmd,ParWin.split('.')[0],False)
         
        
        

#end of definition for class SilkTest_Handler


        
############################################################################################
class Click(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode=True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform the Initial Parse on the command
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'

        self.SilkCmd = ""
        i = 0
        ComObject = pTestStep.getItem('object')
        ObjectType2 = self.returnType(ComObject)
        #if the data section contains '(0.9, 0.9)', should call ClickOnCoordinate()
        if re.match('\(.*[0-9.].*\)', str(pTestStep.getItem('data'))):
            try:
                positions = pTestStep.getItem('data').split(',')
                PosX = re.sub('\(| ','',positions[0])
                PosY = re.sub('\)| ','',positions[1])
                if float(PosX)>1 or float(PosX)<0 or float(PosY)>1 or float(PosY)<0:
                    print 'Error in the Coordinate. Either < 0 or > 1 or characters' 
                    return 'Error'
            except:
                print 'Error in the Coordinate.' 
                return 'Error'
            self.SilkCmd = 'ClickOnCoordinate(' + self.OnePath + ', 1, '+ PosX +', '+ PosY +' )'
        elif ObjectType2 in [self.Menu2, self.MenuMenu2, self.MenuMenuMenu2]:
            self.SilkCmd = 'LeftClick(' + self.OnePath + ', "NULL", "' + str(pTestStep.getItem('data')) + '")'
        elif ObjectType2 in [self.TextField2, self.RadioButton2, self.Tab2, self.List2, self.Node2, self.Button2, self.Tree2, self.TreeNode2, self.TreeNodeNode2, self.TreeNodeNodeNode2, self.TreeNodeNodeNodeNode2, self.TreeNodeNodeNodeNodeNode2, self.TreeNodeNodeNodeNodeNodeNode2, self.TreeNodeNodeNodeNodeNodeNodeNode2]:
            self.SilkCmd = 'LeftClick(' + self.OnePath + ', "NULL", "' + self.getObjectPath(ObjectType2, pTestStep)+ '")'
        elif ObjectType2 in [self.ListText2, self.ListRadioButton2]:
            self.SilkCmd = 'LeftClick(' + self.OnePath + ', "' + self.getObjectPath(ObjectType2, pTestStep)[0]+ '", "' + self.getObjectPath(ObjectType2, pTestStep)[1]+ '")'
        elif ObjectType2 == self.LeftArrow2:
            self.SilkCmd = self.OnePath + '.LeftArrow()'
        elif ObjectType2 == self.RightArrow2:
               self.SilkCmd = self.OnePath + '.RightArrow()'                     
        elif ObjectType2 ==  self.Table2:
            lst = self.getObjectPath(ObjectType2, pTestStep)
            #According to S_Via test, value should be in this order; 2, 1, 3
            self.SilkCmd = 'ClickOnTable('+self.WinPath[0]+','+self.OnePath+',"'+lst[2]+'","'+lst[1]+'","'+lst[3]+'")'
                
        elif ObjectType2 == self.Error2:
            print 'Wrong object type or action \'Click\' for ' + pTestStep.getItem('line') + ' has not implemented yet'  
            return 'Error' 
            
        else:
            for Line in self.PathCmd:
                if(i > 0):
                    self.SilkCmd += ' && '
                    #Build the Silktest Command
                self.SilkCmd += 'LeftClick(' + Line + ', "NULL", "' + str(pTestStep.getItem('data')) + '")'
                i += 1
            
       
        if bGenerateCode:
            #Generate the Silktest File
            self.GenerateCode(pTestStep, self.SilkCmd, self.WinPath[0], True)
           
        return 'Ok'        
############################################################################################


class DbClick(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform the Initial Parse on the command
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        SilkCmd = ""
        i = 0
        
        ComObject = pTestStep.getItem('object')
        ObjectType2 = self.returnType(ComObject)
        if ObjectType2 in [self.TreeNode2, self.TreeNodeNode2, self.TreeNodeNodeNode2, self.TreeNodeNodeNodeNode2, self.TreeNodeNodeNodeNodeNode2]:
            SilkCmd = 'DbClick(' + self.OnePath + ',"' + self.getObjectPath(ObjectType2, pTestStep)+ '")'
        else:    
          for Line in self.PathCmd:
              if(i > 0):
                  SilkCmd += ' && '
                  #Build the Silktest Command
              SilkCmd += 'DbClick(' + Line +', "NULL")'
              i += 1
        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep, SilkCmd, self.WinPath[0], True)
           
        return 'Ok'
        
############################################################################################
 
class Select(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform the Initial Parse on the command
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        self.SilkCmd = ""
        i = 0

        #Generate Code for the Left Clicks
        for Line in self.PathCmd:
            if(i > 0):
                self.SilkCmd += ' && '
            #Build the Silktest Command
            self.SilkCmd += 'LeftClick(' + Line + ', "NULL", ' + str(pTestStep.getItem('data')) + ')'
            i += 1
        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep, self.SilkCmd, self.WinPath[0], True)
        return 'Ok'        
############################################################################################

class RClick(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform the Initial Parse
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        #Get Size of the command Object
        #Right Click click on the object at the select text if it exists
        CmdLength = len(pTestStep.getItem('object').split('/')) - 1
        ComObject = pTestStep.getItem('object')
        ObjectType2 = self.returnType(ComObject)
        #if it has the coordinate in the data section
        if re.match('\(.*[0-9.].*\)', str(pTestStep.getItem('data'))):
            try:
                positions = pTestStep.getItem('data').split(',')
                PosX = re.sub('\(| ','',positions[0])
                PosY = re.sub('\)| ','',positions[1])
                if float(PosX)>1 or float(PosX)<0 or float(PosY)>1 or float(PosY)<0:
                    print 'Error in the Coordinate. Either < 0 or > 1' 
                    return 'Error'
            except:
                print 'Error in the Coordinate.' 
                return 'Error'
            SilkCmd = 'ClickOnCoordinate(' + self.OnePath + ', 2, '+ PosX +', '+ PosY +' )'
        #If object is title bar, call RightClickOnTitleBar
        elif ObjectType2 == 'tb':
            SilkCmd = 'RightClickOnTitleBar('+self.WinPath[0]+')'
            
        else:
            SilkCmd = 'RightClick(' + self.PathCmd[0] + ',"' + self.Add_Stars(self.cutType(pTestStep.getItem('object').split('/')[CmdLength])) + '")'
        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep, SilkCmd, self.WinPath[0], True)
        return 'Ok'        
############################################################################################

class Popup_Select(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform the Initial Parse
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        OnelineObject = pTestStep.getItem('object')
        CmdObj = pTestStep.getItem('object').split('/')
        ObjectType2 = self.returnType(OnelineObject)
        if ObjectType2 in [self.Menu2, self.MenuMenu2, self.MenuMenuMenu2]:
            SilkCmd = 'SelectPopup(' + self.PathCmd[0] + ',"' + 'NULL' + '","' + self.getObjectPath(ObjectType2, pTestStep) + '")'
        elif ObjectType2 in [self.TreeMenuMenu2, self.ListMenu2, self.TreeMenu2, self.TreeNodeNodeMenu2, self.TreeNodeMenu2, self.TreeNodeMenuMenu2]:
            path = self.getObjectPath(ObjectType2, pTestStep)
            SilkCmd = 'SelectPopup(' + self.PathCmd[0] + ',"' + path[0] + '","' + path[1] + '")'
        else:
            print 'Unexpected object type found in SelectPopup()'
            print ObjectType2
            return 'Error'    
        
        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep, SilkCmd, self.WinPath[0], True)
        return 'Ok'
############################################################################################

class Enter(SilkTest_Handler):
    def Execute(self, pTestStep, pTestCase):
        if pTestStep.getParameter('handleatruntime'):
            self.Pre_Execute(pTestStep)
            
        return SilkTest_Handler.Execute(self, pTestStep, pTestCase)
        
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform the Initial Parse
        if (self.Init_Parser(pTestStep) == 'Error'):
            print 'Error in Enter InitParser'
            return 'Error'
        SilkCmd = ""
       
        data = pTestStep.getItem('data')
        
        #Remembered variables may exist later, so flag for runtime execution
        if str(data)[0] == '#':
            pTestStep.setParameter('handleatruntime',True)
        
        #If we found no quotes, put quotes around it for Silktest
        if str(data)[0] == '"':
            pass
        else:
            pTestStep.setItem('data','"' + str(data) + '"')
            
        ComObject = pTestStep.getItem('object')
        #ObjectType = self.DetermineType(ComObject)
        ObjectType2 = self.returnType(ComObject)
        if(ObjectType2 == self.TextField2):
            lst = self.getObjectPath(ObjectType2, pTestStep)
            SilkCmd = 'EnterParmInList('+self.WinPath[0]+','+self.OnePath+',"NULL", "'+lst+'",'+str(pTestStep.getItem('data'))+')'
            
        elif(ObjectType2 == self.PullDown2):
            pullDownName = self.getObjectPath(ObjectType2, pTestStep)
            SilkCmd += 'EnterParmInListPulldown('+self.WinPath[0]+', '+re.sub("\.[^\.]*$", "", self.OnePath)+', '+self.OnePath+', '+str(pTestStep.getItem('data'))+', "NULL", "'+pullDownName +'")' 
        
             
        elif(ObjectType2 == self.ListText2):
            lst = self.getObjectPath(ObjectType2, pTestStep)
            SilkCmd = 'EnterParmInList('+self.WinPath[0]+','+self.OnePath+',"'+lst[0]+'","'+lst[1]+'",'+str(pTestStep.getItem('data'))+')'
        
        elif(ObjectType2 == self.ListPullDown2):
            ParWin = re.sub('\.\w+\Z','',self.OnePath)
            lst = self.getObjectPath(ObjectType2, pTestStep)
            SilkCmd += 'EnterParmInListPulldown(%s,%s,%s, %s, "%s", "%s")' % (self.WinPath[0], re.sub("\.[^\.]*$", "", self.OnePath),  self.OnePath, str(pTestStep.getItem('data')), lst[0], lst[1])
        
        elif(ObjectType2 == self.Table2):
            lst = self.getObjectPath(ObjectType2, pTestStep)
            SilkCmd += 'Enter(' + self.WinPath[0] + ',' + self.OnePath + ',"' + str(pTestStep.getItem('data')) + '","' + lst[2] + '","' + lst[1] + '","' + lst[3] + '")'
        #else: put it in the loop    
        else:
            for Line in self.PathCmd:
                #Get the Parent Window
                ParWin = re.sub('\.\w+\Z','',Line)
                i = 0
                if(i > 0):
                    SilkCmd += ' && '
                SilkCmd += 'Enter(' + ParWin + ',' + Line + ',' + str(pTestStep.getItem('data')) + ', "' + self.cutType(pTestStep.getItem('object').split('/')[i]) + '","NULL")'
                i += 1                          
        
        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,SilkCmd,self.WinPath[0],True)
        return 'Ok'
############################################################################################

class Close(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform the Initial Parse
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        self.SilkCmd = ""
        #Build the Silk Commmand
        self.SilkCmd = 'Close('+ self.WinPath[0] + ')'

        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,self.SilkCmd,self.WinPath[0],True)
        return 'Ok'
############################################################################################

class Q_Equals(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
       # rem = Remember(pTestStep)
       # rem.Pre_Execute(pTestStep)
        if (self.Init_Parser(pTestStep) == 'Error'):
             return 'Error'
        self.Remember(pTestStep, bGenerateCode)
        return 'Ok'
        
    def Compare(self, ReferenceString, ReturnedString):
        DataType = 's'
        Data = "Null"
        Units ='nm'
        ReturnedDataType = 's'
        ReturnedData = "Null"
        ReturnedUnits ='nm'
        Data, Units, DataType = self.ParseCommand(ReferenceString)
        ReturnedData, ReturnedUnit, ReturnedDataType = self.ParseCommand( ReturnedString)
        #TODO: do float conversions one time, within a try/except block then use. ex. dataFloat = float(data)
        #Only when DataType is number
        try:
            ReturnedData = eval(ReturnedData)
            Data = eval(Data)
            print "Comparing %s with %s" %(ReturnedData, Data)
        except:
            self.logger.error("Could not calculate the data")
        if(DataType in  ['n','not','>','<']):
                if ( (False == Utility().isConvertableToFloat(Data)) or (False == Utility().isConvertableToFloat(ReturnedData)) ):
                    print 'ERROR in Q_Equals.Execute: Data or value not convertable to float: ' + str(Data) + ' ' + str(ReturnedData)
                    return 'Fail'
        if(DataType == '>'):
            if (float(ReturnedData) > float(Data)):
                return 'Pass'
        elif(DataType == '<'):
            if(float(ReturnedData) < float(Data)):
                return 'Pass'
        elif(DataType == 'not'):
            if(not(float(ReturnedData) == float(Data))):
                return 'Pass'
        #handle string and number in the same way
        elif(DataType == 'n'):
            if (float(Data)== float(ReturnedData)):
                return 'Pass'
        elif(DataType == 's'):
            #filter out python common regular expression simbols from strings
            #use \s, which means ANY white space (\t\n etc)
            sVal = re.sub('\s','',ReturnedString).lower()
            sData = re.sub('\s','',Data).lower()
            if sData == sVal:
                return 'Pass'
            else:
                print 'Reference(%s) Returned(%s)'%(sData, sVal)
        else:
            if(float(Data) == float(ReturnedData)):
                return 'Pass'
        print 'Q_Equals pTestStep Failed.  Returned Value was (' + str(ReturnedData)+ ')'
        return 'Fail'
    
           
             
    def Execute(self, pTestStep, pTestCase):
        #TODO: break up into smaller testable methods
        
        try:
            passfail = SilkTest_Handler.Execute(self, pTestStep, pTestCase)
            if (passfail != 'Pass'):
                return 'Fail'
            #Creates the expected filename in which Silktest should have put its result and get the real value from the result file
            testname = pTestStep.getParameter('testname')
            testname = self.U.removeKnownExtensions(testname)
            
            txtFile = open(testname + '_' + re.sub('\.','_',pTestStep.getItem('line').getStr())+ '.txt',  'r')
            txtlines = txtFile.readlines()
            txtFile.close()
            try:
                sVal = txtlines[3]
            except:
                print "Remember function did not return any value"
                return "Fail"
            #call a comparing function
            p = re.compile("\[.*\]+")
            if p.search(pTestStep.getItem('data') )!=None:
                Data, Units, DataType = self.ParseCommand(pTestStep.getItem('data') )
                eData = eval(Data)
                if not DataType in ('n', 's'):
                    eData = DataType + str(eData)
                pTestStep.setItem('data', eData)
            return self.Compare(pTestStep.getItem('data') , sVal)
        except:
            print "ERROR in Q_Equals.Execute, default exception case hit"
            (ErrorType, ErrorValue, ErrorTB) = sys.exc_info()
            print sys.exc_info()
            return 'Fail'
        
      
    def ParseCommand(self, cmdstr):
        #Parse the data to check for strings, number, >, or <

        if(re.match('\".*\"',str(cmdstr))):
            # string
            Data = re.sub('\"','',str(cmdstr))
            DataType = 's'
            Units = 'nm'
        else:
            Data = self.ParseValue(cmdstr)
            Units = self.ParseUnits(cmdstr)
            if(not re.match('.*[0-9].*', str(cmdstr))):
                DataType = 's'
                return Data, Units, DataType
            if(re.match('.*\>.*',str(cmdstr))):
                # greater than number   
                DataType = '>'
            elif(re.match('.*\<.*',str(cmdstr))):
                # smaller than number
                DataType = '<'
            elif(re.match('.*[nN]ot.*',str(cmdstr))):
                DataType = 'not'
            else:
                # equals
                DataType = 'n'
        return Data, Units, DataType

    #returns the unit of command data
    def ParseUnits(self, cmdstr):
        if re.match('.*[0-9].*', str(cmdstr)):
            return re.sub('[0-9\.\-\+\>\<\[\]\)\(\/\*]|not','',str(cmdstr)).strip()
        else:
            return 'none'

    #returns the value of the command data
    def ParseValue(self, cmdstr):
        #only if it has some number
        if re.match('.*[0-9].*', str(cmdstr)):
            return re.sub('[^0-9\.\-\+\*\/\^\(\)]','',str(cmdstr))
        else:
            return str(cmdstr)

 ############################################################################################

    
class Q_EqualsApprox(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #call Pre_Execute of Remember
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        self.Remember(pTestStep, bGenerateCode)
        return 'Ok'

    def return_Data_Percentage(self, ReferenceString):
        DataList = ReferenceString.split(',')
        DataList[0] = re.sub(' ','',re.sub('[a-zA-Z]','',DataList[0])) #Remove nm or other units
        DataList[1] = re.sub('\%','',DataList[1])  #remove the %  
        if DataList[0] == None or DataList[1] == None:
            return 'None' 
        return (DataList[0], DataList[1]) 
        
        
    def Compare(self, ReferenceData, Percentage  ,ReturnedString):
        ReturnedData = re.sub('[a-zA-Z:;]', '', ReturnedString) #Remove nm or other units
        #TODO: do float conversions one time, within a try/except block then use. ex. dataFloat = float(data)
        try:
            ReferenceData = eval(ReferenceData)
            Percentage = eval(Percentage)
            ReturnedData = eval(ReturnedData)
            print "Comparing %s with %s " %(ReferenceData, ReturnedData)
        except:
            print "Could not calculate the value"
        if ( not (Utility().isConvertableToFloat(ReferenceData) and Utility().isConvertableToFloat(Percentage) and Utility().isConvertableToFloat(ReturnedData))):
            print 'ERROR in Q_EqualsApprox.Execute: Data or Percentage not convertable to float: ' + ReferenceData + ' ' + Percentage
            return 'Fail'
        threshold = abs((float(ReferenceData)*(float(Percentage)/100)))
        try:
            if( float(ReferenceData)-threshold <= float(ReturnedData)) and (float(ReturnedData)<= float(ReferenceData)+threshold):
              return 'Pass'
            else: 
              print 'Q_EqualsApprox pTestStep Failed.  Returned Value was (' + str(float(ReturnedData)) + ')'
              return 'Fail'
        except:
            print 'Q_EqualsApprox pTestStep Failed. '
            return 'Fail'
            
    def Execute(self, pTestStep, pTestCase):
        try:
            passfail = SilkTest_Handler.Execute(self, pTestStep, pTestCase)
            if (passfail != 'Pass'):
                return 'Fail'
            DataList = self.return_Data_Percentage(str(pTestStep.getItem('data')))
           #Creates the expected filename in which Silktest should have put its result and get the real value from the result file
            testname = pTestStep.getParameter('testname')
            testname = self.U.removeKnownExtensions(testname)
            
            txtFile = open(testname + '_' + re.sub('\.','_',pTestStep.getItem('line').getStr())+ '.txt',  'r')
            txtlines = txtFile.readlines()
            txtFile.close()
            try:
                sVal = txtlines[3]
            except:
                print "Remember did not return any value"
                return "Fail"
           #TODO: do float conversions one time, within a try/except block then use. ex. dataFloat = float(data)
            return self.Compare(DataList[0], DataList[1], sVal)
          
        except:
            print "ERROR in Q_EqualsApprox.Execute, default exception case hit"
            (ErrorType, ErrorValue, ErrorTB) = sys.exc_info()
            print sys.exc_info()
            return 'Fail'    
        
          

 ############################################################################################

class Q_Focus(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)

        #Perform the Initial Parse on the command
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'

        #Build the Silk Command
        SilkCmd = "Focused(" + self.OnePath + ")"

        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,SilkCmd,self.WinPath[0],True)
        return 'Ok'
############################################################################################

class Remember(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        #Perform the Initial Parse on the command
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        self.Remember(pTestStep, bGenerateCode)
        return 'Ok'
        
    def Execute(self, pTestStep, pTestCase):
        passfail = SilkTest_Handler.Execute(self, pTestStep, pTestCase)
        #REMEMBER action, gather data from file and pile into command.
        if passfail == 'Pass':
            try:
                #Creates the expected filename in which Silktest should have put its result
                testname = pTestStep.getParameter('testname')
                testname = self.U.removeKnownExtensions(testname)
                
                txtFile = open(testname + '_' + re.sub('\.','_',pTestStep.getItem('line').getStr())+ '.txt',  'r')
                txtlines = txtFile.readlines()
                
                lineReadyForEncoding = ""
                for char in txtlines[3]:
                    try:
                        u = unicode( char, "utf-8" )
                        lineReadyForEncoding += u
                    except UnicodeDecodeError:
                        if (ord(char) == 181):
                            lineReadyForEncoding += "u"
                        else:
                            print "ERROR WITH UNICODE ENCODING: Special character will be removed to allow for report creation."
                pTestCase.setParameter(pTestStep.getItem('data'),lineReadyForEncoding)
                pTestStep.setItem('data',lineReadyForEncoding)
                txtFile.close()
                return 'Pass'
            except:
                print 'ERROR in remember function, no file found.  Line: ' + pTestStep.getItem('line')
                return 'Fail'
        else:
            return passfail
            
 ############################################################################################      

class ScreenShot(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform an initial parse on the command object
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        data = str(pTestStep.getItem('data'))
        if data == 'none':
            print 'No Name for Screen Capture at line ' + pTestStep.getItem('line')
            return 'Error'
        else:
            data = re.sub('"','',data)
            data = re.sub(' ','',data)
            timeStamp = time.strftime("%m%d%H%M%S", time.localtime(time.time()))
            filename = data + '_' + timeStamp + '.bmp'
            pTestStep.setItem('data',filename)
            
        #Build the Silk Command
        SilkCmd = 'Agent.SetOption(OPT_BITMAP_MATCH_COUNT , 0) && ScreenShot(' + self.WinPath[0] + ',"' + filename + '")'

        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,SilkCmd,self.WinPath[0],True)
        return 'Ok'
    
    def Execute(self, pTestStep, pTestCase):
        passfail = SilkTest_Handler.Execute(self, pTestStep, pTestCase)
        if (passfail != 'Pass'):
            return 'Fail'
       
        screenspath = pTestStep.getParameter('screenspath')#DS.getScreensPath()
        filename = pTestStep.getItem('data')
        fileinscreens = screenspath + '\\' + filename
        try:
            shutil.copy(filename, fileinscreens)
            return 'Pass'
        except:
            print 'ERROR: Could not copy screen capture file %s'%(filename)
            return 'Fail'
        
 ############################################################################################

class Q_Closed(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform an initial Parse on the command Object
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'

        #Build the Silk Command
        SilkCmd = 'Closed(,' + self.WinPath[0] + ')'

        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,SilkCmd,self.WinPath[0],True)
        return 'Ok'
 ############################################################################################

class Focus(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform an initial Parse on the command Object
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'

        #Build the Silk Command
        SilkCmd = 'SetActive(' + self.WinPath[0] + ')'

        #Generate the SilkTest File
        self.GenerateCode(pTestStep,SilkCmd,self.WinPath[0],True)
        return 'Ok'
 ############################################################################################
class Q_Status(SilkTest_Handler):
           #Momentary Place Holder (to check if something is checked, selected, green, unchecked, not selected)
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform the Initial Parse on the command
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        ComObject = pTestStep.getItem('object')
        ObjectType = self.returnType(ComObject)
        Data = re.sub(' ','',pTestStep.getItem('data')).lower()
        if ObjectType in [self.RadioButton2, self.ListRadioButton2 ]:
            ButtonName = ''
            if ObjectType == self.RadioButton2:
                ButtonName = self.getObjectPath(ObjectType, pTestStep)
            else:
                ButtonName = self.getObjectPath(ObjectType, pTestStep)[1] 
            if Data == 'selected':
                SilkCmd = 'isRadioButtonSelected( ' + self.WinPath[0] + ', ' + self.OnePath +', "'+ ButtonName+'")'
            elif Data == 'unselected':
                SilkCmd = '! isRadioButtonSelected( ' + self.WinPath[0] + ', ' + self.OnePath +', "'+ ButtonName+'")'
            else:
                print 'Unexpected data: ', Data, 'for checking Status of Radio button'
                return 'Error'
            
        elif(ObjectType == self.CheckBox2):
            if Data == 'checked':
                SilkCmd = 'isCheckBoxChecked( '+ self.WinPath[0] + ', ' + self.OnePath +' )'
            elif Data == 'unchecked':
                SilkCmd = '! isCheckBoxChecked( '+ self.WinPath[0] + ', ' + self.OnePath +' )'
            else:
                print 'Unexpected data: ', Data, 'for checking Status of Checkbox'
                return 'Error'
                
        elif(ObjectType == self.Button2):
            if Data == 'active':
              #Build the Silk Command
              SilkCmd = 'isButtonEnabled( '+ self.WinPath[0] + ', ' + self.OnePath +' )'
            elif Data == 'inactive':
              SilkCmd = '! isButtonEnabled( '+ self.WinPath[0] + ', ' + self.OnePath +' )'
            else:
              print 'Unexpected data: ', Data, 'for checking Status of Pushbutton'
              return 'Error'
        elif ObjectType in [self.ListTab2, self.ListText2]:
            listName = self.getObjectPath(ObjectType, pTestStep)[0]
            ValueName = self.getObjectPath(ObjectType, pTestStep)[1]  
            if Data == 'green':
                SilkCmd = 'isGreen( '+self.OnePath +', "'+listName + '", "' + ValueName + '" )' 
            elif Data == 'notgreen':
                SilkCmd = '! isGreen( '+self.OnePath +', "'+listName + '", "' + ValueName + '" )' 
            else:
                print 'Unexpected data: ', Data, 'for checking Status of Pushbutton'
                return 'Error'
                
        else:
            print'Unexpected object type in ?Status.'
            return 'Error'
        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,SilkCmd,self.WinPath[0],True)
        return 'Ok'
 ############################################################################################
 
class Launch(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform an initial Parse on the command Object
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'

        #Build the Silk Command
        SilkCmd = 'Launch(,' + str(pTestStep.getItem('data')) + ')'
        SilkCmd = '&& sleep(20)'

        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,SilkCmd,self.WinPath[0],True)
        return 'Ok'
 ############################################################################################

class Q_Exists(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform an initial Parse on the command Object
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'

        #Build the Silk Command
        SilkCmd = 'Exists(,' + self.WinPath[0] + ')'

        #Generate the SilkTest File
        self.GenerateCode(pTestStep,SilkCmd,self.WinPath[0],True)
        return 'Ok'
 ############################################################################################
class Open_Nanoscope(SilkTest_Handler):
     def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
      #   if (self.Init_Parser(pTestStep) == 'Error'):
       #     return 'Error'
         #open nanoscope with the path in the data field
        os.system(str(pTestStep.getItem('data')) )
        return 'Ok'         
 ############################################################################################

class Drag(SilkTest_Handler):
    
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        if (self.Init_Parser(pTestStep) == 'Error'):
           return 'Error'
        #get the data: format (0,5, 0.9) to (0.9, 0.9)
        Data = pTestStep.getItem('data')
        
        if 'none' == pTestStep.getItem('data'):
            print 'No Data Found for Drag pTestStep line ' + pTestStep.getItem('line')
            return 'Error'
        try:
            startXY, endXY = self.returnXYPairs(Data)
            if startXY == None or endXY == None:
                raise
        except:
            print "Unrecognized data format in Drag function: ", Data
            return "Error"
                  
        #Build the Silktest Command
        SilkCmd = 'DragDrop(' + self.OnePath + ',' + startXY[0]+ ',' +  startXY[1]+',' + endXY[0]+ ',' + endXY[1] +  ')'
        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,SilkCmd,self.WinPath[0],True)
        return 'Ok'
    def returnXYPairs(self, Data):
        Start = End = None
        Start = Data.split('to')[0]
        End = Data.split('to')[1]
        startX = re.sub('\(| ','',Start.split(',')[0])
        startY = re.sub('\)| ','',Start.split(',')[1])
        endX = re.sub('\(| ','',End.split(',')[0])
        endY = re.sub('\)| ','',End.split(',')[1])
        StartXY = (startX, startY)
        EndXY = (endX, endY)
        return StartXY, EndXY
    
          
        
       
 ############################################################################################

class ClickHold(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform an initial Parse on the command Object
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        #get the integer value from the data
        str1 = re.sub('[sS]','',pTestStep.getItem('data'))
        #Build the Silktest Command
        SilkCmd = 'ClickHold(' + self.OnePath + ',' + str1 + ')'

        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,SilkCmd,self.WinPath[0],True)
        return 'Ok'
       

 ############################################################################################

class PressKey(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Momentary Place Holder
        self.GenerateCode(pTestStep,"",'Nanoscope',False)
        print 'pTestStep ' + pTestStep.getItem('line') + ' PressKey handler not implemented yet.' + ' Data = ' + pTestStep.getItem('data')
        return 'Ok'
 ############################################################################################
 
class EndTest(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,"",'Nanoscope',False)
        return 'Ok'
    
    def Execute(self, pTestStep, pTestCase):
        #Set data to be time stamp
        pTestStep.setItem('data',GetCurrentTime())
        print 'The endtime is '+ pTestStep.getItem('data')
        return 'Pass'        

 ############################################################################################

class Wait(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform an initial Parse on the command Object
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        #get the integer value from the data
        seconds = re.sub('[sS]','',pTestStep.getItem('data'))
        #Build the Silktest Command
        SilkCmd = 'Sleep(' + seconds + ')'
        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,SilkCmd,self.WinPath[0],True)
        return 'Ok'
############################################################################################

class Left_Popup_Select(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform the Initial Parse
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        OnelineObject = pTestStep.getItem('object')
        CmdObj = pTestStep.getItem('object').split('/')
        ObjectType2 = self.returnType(OnelineObject)
        if ObjectType2 in [ self.Menu2, self.MenuMenu2, self.MenuMenuMenu2]:
            SilkCmd = 'LeftSelectPopup(' + self.PathCmd[0] + ',"' + 'NULL' + '","' + self.getObjectPath(ObjectType2, pTestStep) + '")'
        elif ObjectType2 in [self.ButtonMenu2,self.TreeMenuMenu2, self.ListMenu2, self.TreeMenu2, self.TreeNodeNodeMenu2, self.TreeNodeMenu2, self.TreeNodeMenuMenu2]:
            path = self.getObjectPath(ObjectType2, pTestStep)
            SilkCmd = 'LeftSelectPopup(' + self.PathCmd[0] + ',"' + path[0] + '","' + path[1] + '")'
        else:
            print 'Unexpected object type found in LeftSelectPopup()'
            return 'Error'    
        
       #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,SilkCmd,self.WinPath[0],True)
        return 'Ok'
############################################################################################
class Right_Click_Titlebar(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        if(self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        SilkCmd = 'RightClickOnTitleBar('+self.WinPath[0]+')'
        
        self.GenerateCode(pTestStep, SilkCmd, self.WinPath[0], True)
############################################################################################

class Minimize(SilkTest_Handler):
    def Pre_Execute(self, pTestStep, bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform the Initial Parse
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        self.SilkCmd = ""
        #Build the Silk Commmand
        self.SilkCmd = 'Minimize('+ self.WinPath[0] + ')'
        #Generate the Silktest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,self.SilkCmd,self.WinPath[0],True)
        return 'Ok'
        
############################################################################################
class Press_Key(SilkTest_Handler):
    def Pre_Execute(self,pTestStep,bGenerateCode = True):
        SilkTest_Handler(pTestStep.getItem('data')).Pre_Execute(pTestStep)
        #Perform the Initial Parse
        if (self.Init_Parser(pTestStep) == 'Error'):
            return 'Error'
        self.SilkCmd = ""
        #Build the Silk Commmand
        self.SilkCmd = 'KeyStroke('+ self.WinPath[0] + ',"'+pTestStep.getItem('data')+'")'
        #Generate the SilkTest File
        if bGenerateCode:
            self.GenerateCode(pTestStep,self.SilkCmd,self.WinPath[0],True)
        return 'Ok'
        
        
        
        
############################################################################################
