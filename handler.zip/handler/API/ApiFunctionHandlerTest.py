# tests for DDTAF's ApiFunctionHandler


from ApiFunctionHandler import *
import unittest, math


class ApiFunctionHandlerTest(unittest.TestCase):
    #def setUp(self): pass
    #def tearDown(self): pass

    def testCreation(self):  ## test method names begin 'test*'
        handler = ApiFunctionHandler(None, None)
        self.assert_(1)
        
        
    def testHandle_CommandAvailable(self):
        handler = ApiFunctionHandler(None, None)
        result = handler.Handle_Command(None)
        self.assertEquals('Error', result) # error because None command object
        
        
    def testExecuteAvailable(self):
        handler = ApiFunctionHandler(None, None)
        result = handler.Execute(None)
        self.assertEquals('Fail', result) # error because None command object
  
        
    def testMakeArgumentList(self):
        handler = ApiFunctionHandler(None, None)
        self.assertEquals([''], handler.makeArgumentList(''))
        self.assertEquals(['void'], handler.makeArgumentList('void'))   
        self.assertEquals(['1', '2'], handler.makeArgumentList('1,2'))  
        self.assertEquals(['1', '2'], handler.makeArgumentList('1, 2'))    
        self.assertEquals(['1', '2', '3'], handler.makeArgumentList('1, 2,3'))     
 
 
    def testHandle_CommandVoidVoid(self):
        apiDB = ApiMappingDatabaseForTest()
        apiMapping1 = ApiMapping('zapi', 'realtime', 'void', 'RealTime', 0, 'void')
        apiDB.addMapping( apiMapping1)
        
        class zApi:
            def RealTime(self):
                pass
        
        class zApiGroup:
            zapi = zApi()
            
        handler = ApiFunctionHandler(apiDB, zApiGroup())
        self.assertEquals('raise "ERROR: no executableString available"', handler.executableString) 
        
        # __init__(self, line, window, object, action, data, Pass, Fail, exe_mode, testName):
        command = TestStep(1, 'zApi', 'realtime', 'exceute', '', 'Continue', 'Abort', 'None', 'None')
        self.assertEquals('Ok', handler.Handle_Command(command))
        self.assertEquals('self.apiGroup.zapi.RealTime();success=(True);command.setData(result)', handler.executableString)  
   
        
    def testHandle_CommandBoolVoid(self):
        apiDB = ApiMappingDatabaseForTest()
        apiMapping1 = ApiMapping('zapi', 'realtime', '==True', 'RealTime', 0, 'void')
        apiDB.addMapping( apiMapping1)
        
        handler = ApiFunctionHandler(apiDB, None)
        self.assertEquals('raise "ERROR: no executableString available"', handler.executableString) 
        
        # __init__(self, line, window, object, action, data, Pass, Fail, exe_mode, testName):
        command = TestStep(1, 'zApi', 'realtime', 'exceute', '', 'Continue', 'Abort', 'None', 'None')
        self.assertEquals('Ok', handler.Handle_Command(command))
        self.assertEquals('self.apiGroup.zapi.RealTime();success=(result==True);command.setData(result)', handler.executableString) 
         
        
    def testHandle_CommandInvalid(self):
        apiDB = ApiMappingDatabaseForTest()
        apiMapping1 = ApiMapping('zapi', 'realtime', 'void', 'RealTime', 0, 'void')
        apiDB.addMapping( apiMapping1)
        
        handler = ApiFunctionHandler(apiDB, None)
        self.assertEquals('raise "ERROR: no executableString available"', handler.executableString) 
        
        # __init__(self, line, window, object, action, data, Pass, Fail, exe_mode, testName):
        command = TestStep(1, 'junk', 'realtime', 'exceute', '', 'Continue', 'Abort', 'None', 'None')
        self.assertEquals('Error', handler.Handle_Command(command))
        self.assertEquals('raise "ERROR: no executableString available"', handler.executableString) 
        
            
    def testHandleAndExecuteSimpleVoidFunction(self):
        apiDB = ApiMappingDatabaseForTest()
        apiMapping1 = ApiMapping('tempapi', 'simple', 'void', 'Simple', 0, 'void')
        apiDB.addMapping( apiMapping1)
        
        class ActionTracker:  # to verify that the function was called
            tempSet = False
            
        actionTracker = ActionTracker()
        
        class TempApi:
            def Simple(self):
                actionTracker.tempSet = True
        
        class zApiGroup:
            tempapi = TempApi() 
            
        zapigroup = zApiGroup()
        
        handler = ApiFunctionHandler(apiDB, zapigroup)
        self.assertEquals('raise "ERROR: no executableString available"', handler.executableString) 
        
        # __init__(self, line, window, object, action, data, Pass, Fail, exe_mode, testName):
        command = TestStep(1, 'tempapi', 'simple', 'exceute', '', 'Continue', 'Abort', 'None', 'None')
        self.assertEquals('Ok', handler.Handle_Command(command))
        self.assertEquals('self.apiGroup.tempapi.Simple();success=(True);command.setData(result)', handler.executableString)  

        result = handler.Execute(command)
        self.assertEquals('Pass', result) 
        self.assertEquals(True, actionTracker.tempSet) 


    def testHandleAndExecuteDoubleDoubleDoubleFunction(self):
        apiDB = ApiMappingDatabaseForTest()
        apiMapping1 = ApiMapping('tempapi', 'hypothenuse', '==5', 'Hypothenuse', 2, 'p1,p2')
        apiDB.addMapping( apiMapping1)

        
        class TempApi:
            def Hypothenuse(self, x, y):
                return math.hypot(x, y)
        
        class zApiGroup:
            tempapi = TempApi() 
            
        zapigroup = zApiGroup()
        
        handler = ApiFunctionHandler(apiDB, zapigroup)
        self.assertEquals('raise "ERROR: no executableString available"', handler.executableString) 
        
        # __init__(self, line, window, object, action, data, Pass, Fail, exe_mode, testName):
        command = TestStep(1, 'tempapi', 'hypothenuse', 'exceute', '3, 4', 'Continue', 'Abort', 'None', 'None')
        self.assertEquals('Ok', handler.Handle_Command(command))
        self.assertEquals('self.apiGroup.tempapi.Hypothenuse(3,4);success=(result==5);command.setData(result)', handler.executableString)  

        result = handler.Execute(command)
        self.assertEquals('Pass', result) 
        
        
    def testHandleAndExecuteStringDoubleStringFunction(self):
        apiDB = ApiMappingDatabaseForTest()
        apiMapping1 = ApiMapping('tempapi', 'savefiles', '==2', 'SaveFiles', 2, 'p1,p2')
        apiDB.addMapping( apiMapping1)

        
        class TempApi:
            def SaveFiles(self, numFiles, fileName):
                return 2
        
        class zApiGroup:
            tempapi = TempApi() 
            
        zapigroup = zApiGroup()
        
        handler = ApiFunctionHandler(apiDB, zapigroup)
        self.assertEquals('raise "ERROR: no executableString available"', handler.executableString) 
        
        # __init__(self, line, window, object, action, data, Pass, Fail, exe_mode, testName):
        command = TestStep(1, 'tempapi', 'savefiles', 'exceute', '3, "files.txt"', 'Continue', 'Abort', 'None', 'None')
        self.assertEquals('Ok', handler.Handle_Command(command))
        self.assertEquals('self.apiGroup.tempapi.SaveFiles(3,"files.txt");success=(result==2);command.setData(result)', handler.executableString)  

        result = handler.Execute(command)
        self.assertEquals('Pass', result) 
   
        
    def testHandleAndExecuteTwoSimpleVoidFunctions(self):
        apiDB = ApiMappingDatabaseForTest()
        apiMapping1 = ApiMapping('tempapi', 'simple', 'void', 'Simple', 0, 'void')
        apiDB.addMapping( apiMapping1)
        apiMapping2 = ApiMapping('tempapi2', 'simple2', 'void', 'Simple2', 0, 'void')
        apiDB.addMapping( apiMapping2)
        
        class ActionTracker:  # to verify that the function was called
            tempSet = False
            tempSet2 = False
            
        actionTracker = ActionTracker()
        
        class TempApi:
            def Simple(self):
                actionTracker.tempSet = True
                
        class TempApi2:
            def Simple2(self):
                actionTracker.tempSet2 = True
        
        class zApiGroup:
            tempapi = TempApi() 
            tempapi2 = TempApi2() 
            
        zapigroup = zApiGroup()
        
        handler = ApiFunctionHandler(apiDB, zapigroup)
        self.assertEquals('raise "ERROR: no executableString available"', handler.executableString) 
        
        # __init__(self, line, window, object, action, data, Pass, Fail, exe_mode, testName):
        command1 = TestStep(1, 'tempapi', 'simple', 'exceute', '', 'Continue', 'Abort', 'None', 'None')
        self.assertEquals('Ok', handler.Handle_Command(command1))
        self.assertEquals('self.apiGroup.tempapi.Simple();success=(True);command.setData(result)', handler.executableString)  

        command2 = TestStep(1, 'tempapi2', 'simple2', 'exceute', '', 'Continue', 'Abort', 'None', 'None')
        self.assertEquals('Ok', handler.Handle_Command(command2))
        self.assertEquals('self.apiGroup.tempapi2.Simple2();success=(True);command.setData(result)', handler.executableString) 
        
        self.assertEquals(False, actionTracker.tempSet) 
        result = handler.Execute(command1)
        self.assertEquals('Pass', result) 
        self.assertEquals(True, actionTracker.tempSet) 
        
        self.assertEquals(False, actionTracker.tempSet2) 
        result2 = handler.Execute(command2)
        self.assertEquals('Pass', result2) 
        self.assertEquals(True, actionTracker.tempSet2) 
        

#########################################################################              
        
if __name__ == '__main__':
    unittest.main()