# tests for DDTAF's ApiMapper

#TODO: add validation of command, re args and parms

from ApiMapper import *
from ApiMappingDataBase import *

import unittest


class ApiMapperTest(unittest.TestCase):
    #def setUp(self): pass
    #def tearDown(self): pass

	def testCreation(self):  ## test method names begin 'test*'
		apiDB = ApiMappingDatabaseForTest()
		apiMapper = ApiMapper(apiDB)
		self.assert_(1)


 	def testMakeArgumentListFromDataString(self):
 		apiMapper = ApiMapper(None)
 		self.assertEquals([''], apiMapper.makeListFromFormattedString(''))
 		self.assertEquals(['1'], apiMapper.makeListFromFormattedString('1'))
 		self.assertEquals(['1', '2'], apiMapper.makeListFromFormattedString('1,2'))
 		self.assertEquals(['1', '2', '3'], apiMapper.makeListFromFormattedString('1,2, 3'))
 		self.assertEquals(['1', '2.3', '3'], apiMapper.makeListFromFormattedString('1,2.3, 3'))
 		self.assertEquals(["file", '3'], apiMapper.makeListFromFormattedString('file, 3'))
 		
 		
 	# Test a private utility function by itself
 	def testMakeArgumentString(self):
 		apiMapper = ApiMapper(None)
 		self.assertEquals('', apiMapper.makeArgumentString([]))
 		self.assertEquals('2.0', apiMapper.makeArgumentString(['2.0']))
 		self.assertEquals('2.0,3.2', apiMapper.makeArgumentString(['2.0', '3.2']))
 		
 	
 	def testGetExecutableStringVoidVoid(self):
		apiDB = ApiMappingDatabaseForTest()
		apiMapping1 = ApiMapping('zApi', 'realtime', 'void', 'Realtime', 0, 'void')
		apiDB.addMapping( apiMapping1)
		
		apiMapper = ApiMapper(apiDB)
		executableString1 = apiMapper.getExecutableString('zApi', 'realtime', '')
		self.assertEquals(executableString1, 'zApi.Realtime()')
		
		apiMapping2 = ApiMapping('zApi', 'realtime2', 'void', 'Realtime2', 0, 'void')
		apiDB.addMapping( apiMapping2)
		executableString2 = apiMapper.getExecutableString('zApi', 'realtime2', '')
		self.assertEquals(executableString2, 'zApi.Realtime2()')	
 	
 	
 	def testGetExecutableStringVoidDoubleDouble(self):
		apiDB = ApiMappingDatabaseForTest()       
		apiMapping1 = ApiMapping('Stage', 'movetoxy', '1', 'MoveToXY', 2, 'p1,p2')
		apiDB.addMapping( apiMapping1)
        		
		apiMapper = ApiMapper(apiDB)
		executableString1 = apiMapper.getExecutableString('Stage', 'movetoxy', '2.1, 3.2')
		self.assertEquals(executableString1, 'Stage.MoveToXY(2.1,3.2)')
	
 	
 	def testGetExecutableStringVoidDoubleDoubleSwitchedOrder(self):
		apiDB = ApiMappingDatabaseForTest()       
		apiMapping1 = ApiMapping('Stage', 'movetoxy', '1', 'MoveToXY', 2, 'p2,p1')
		apiDB.addMapping( apiMapping1)
        		
		apiMapper = ApiMapper(apiDB)
		executableString1 = apiMapper.getExecutableString('Stage', 'movetoxy', '2.1, 3.2')
		self.assertEquals(executableString1, 'Stage.MoveToXY(3.2,2.1)')

		
 	def testGetExecutableStringVoidString(self):
		apiDB = ApiMappingDatabaseForTest()       
		apiMapping1 = ApiMapping('zApi', 'setcapturefileName', '1', 'SetCaptureFileName', 1, 'p1')
		apiDB.addMapping( apiMapping1)
        		
		apiMapper = ApiMapper(apiDB)
		executableString1 = apiMapper.getExecutableString('zApi', 'setcapturefileName', '"file1.000"')
		self.assertEquals(executableString1, 'zApi.SetCaptureFileName("file1.000")')
	
	
	def testIsValidCommand(self):
		apiDB = ApiMappingDatabaseForTest()       
		apiMapping1 = ApiMapping('Stage', 'movetoxy', '1', 'MoveToXY', 2, 'p1,p2')
		apiDB.addMapping( apiMapping1)
        		
		apiMapper = ApiMapper(apiDB)	
		result = apiMapper.isValidCommand('Stage', 'movetoxy', ['1', '2'])
		self.assertEquals(result, 1)
		
		# not enough arguments
		result = apiMapper.isValidCommand('Stage', 'movetoxy', ['1'])
		self.assertEquals(result, 0)
		
		# too many arguments
		result = apiMapper.isValidCommand('Stage', 'movetoxy', ['1', '2', '3'])
		self.assertEquals(result, 0)
		
		# wrong/unavailable API
		result = apiMapper.isValidCommand('Junk', 'movetoxy', ['1', '2'])
		self.assertEquals(result, 0)
	

	def testRemapArgumentOrder(self):
		apiMapper = ApiMapper(None)	
		
		self.assertEquals(['1', '2'], apiMapper.remapArgumentOrder(['1', '2'], ['p1', 'p2']))
		self.assertEquals(['2', '1'], apiMapper.remapArgumentOrder(['1', '2'], ['p2', 'p1']))	
		self.assertEquals(['2', '3', '1'], apiMapper.remapArgumentOrder(['1', '2', '3'], ['p2', 'p3', 'p1']))
		self.assertEquals(['4', '2', '3', '1'], apiMapper.remapArgumentOrder(['1', '2', '3', '4'], ['p4', 'p2', 'p3', 'p1']))
				
		self.assertEquals(['1', '3'], apiMapper.remapArgumentOrder(['1'], ['p1', 'd3']))
		self.assertEquals(['1', '3.0'], apiMapper.remapArgumentOrder(['1'], ['p1', 'd3.0']))
		
		self.assertEquals(['1', 'file.txt'], apiMapper.remapArgumentOrder(['1'], ['p1', 'dfile.txt']))
		self.assertEquals(['1', '"file.txt"'], apiMapper.remapArgumentOrder(['1'], ['p1', 'd"file.txt"']))
		self.assertEquals(['"file.txt"', '1'], apiMapper.remapArgumentOrder(['1', '"file.txt"'], ['p2', 'p1']))		


	def testRemapArgumentOrderOneToOne(self):
		apiMapper = ApiMapper(None)	
		
		self.assertEquals(['1', '2'], apiMapper.remapArgumentOrder(['1', '2'], ['onetoone']))
		self.assertEquals(['2', '1'], apiMapper.remapArgumentOrder(['2', '1'], ['onetoone']))
		self.assertEquals(['2', '1'], apiMapper.remapArgumentOrder(['2', '1'], ['OneToOne'])) # test case
		
		
 	def testGetExecutableStringVoidVoidInvalid(self):
		apiDB = ApiMappingDatabaseForTest()
		apiMapping1 = ApiMapping('zApi', 'realtime', 'void', 'Realtime', 0, 'void')
		apiDB.addMapping( apiMapping1)
		
		apiMapper = ApiMapper(apiDB)
		executableString1 = apiMapper.getExecutableString('junk', 'realtime', '')
		self.assertEquals(executableString1, '')
		
		executableString2 = apiMapper.getExecutableString('zApi', 'realtime', '')
		self.assertEquals(executableString2, 'zApi.Realtime()')
		
		executableString3 = apiMapper.getExecutableString('zApi', 'junk', '')
		self.assertEquals(executableString3, '')

		
	def testGetSuccessCriteriaString(self):
		apiDB = ApiMappingDatabaseForTest()
		apiMapping1 = ApiMapping('zApi', 'realtime', '==True', 'Realtime', 0, 'void')
		apiDB.addMapping( apiMapping1)
		
		apiMapper = ApiMapper(apiDB)
		
		successCriteriaString = apiMapper.getSuccessCriteriaString('zApi', 'realtime')
		self.assertEquals(successCriteriaString, '==True')
		

####################################################################################
					
if __name__ == '__main__':
	unittest.main()