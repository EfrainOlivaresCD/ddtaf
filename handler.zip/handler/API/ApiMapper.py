# Responsibility: maps DDTAF commands to API calls

from ApiMappingDataBase import *
import sys, string, re


class ApiMapper:

	def __init__(self, apiMappingDataBase):
		self.apiDB = apiMappingDataBase

	
	def getExecutableString(self, apiKey, ddtafCmd, dataString):
		
		executableString = ''
		
		try:
			if (False == self.apiDB.isMapping(apiKey, ddtafCmd)):
				#print 'ERROR: ApiMapper.getExecutableString no mapping exists'
				return executableString
			
			mapping = self.apiDB.getMapping(apiKey, ddtafCmd) 
			parmListString = mapping.parmListString
			
			# make list from string
			parmList = self.makeListFromFormattedString(parmListString)			
			argumentListOriginalOrder = self.makeListFromFormattedString(dataString)			
			argumentList = self.remapArgumentOrder(argumentListOriginalOrder, parmList)
			
			if (False == self.isValidCommand(apiKey, ddtafCmd, argumentList)):
				raise "ERROR: command object does not map to an API call"
			
			#executableString += "result=" 		
			executableString += str(mapping.apiName) + '.' + str(mapping.apiCmd) + '('
			
			argumentString = self.makeArgumentString(argumentList)
			executableString += argumentString + ')'
			
		except KeyError:
			#print "ERROR in ApiMapper getExecutableString, KeyError"	
			(ErrorType, ErrorValue, ErrorTB) = sys.exc_info()
			print sys.exc_info()
				
		except:
			print "ERROR in ApiMapper getExecutableString, default exception case hit"
			(ErrorType, ErrorValue, ErrorTB) = sys.exc_info()
			print sys.exc_info()
			
		return executableString
		
		
	#TODO: move this into another DDTAF core class.  It chould/should be generic
	def makeListFromFormattedString(self, dataString):
		#TODO: Add more substitution to handle other charecters. (();:...)
		if ( (dataString == '') or (dataString == 'None')): # or (dataString == 'void') ):
			return ['']
			
		argList = re.sub(' ','',dataString)
		return argList.split(',')
		
	
	def isValidCommand(self, apiName, ddtafCmd, argumentList):	
		if (self.apiDB.isMapping(apiName, ddtafCmd) == False):
			#print 'ApiMapper.isValidCommand  mapping does not exist'
			return False
		
		mapping = self.apiDB.getMapping(apiName, ddtafCmd)
		
		if (mapping.numParms == 0):
			if ( (argumentList == ['']) or (argumentList == ['None']) ):
				return True
			else:
				return False
			
		if (mapping.numParms != len(argumentList)):
			return False
			
		#TODO: add more real validation	???
		return True
		
		
	def remapArgumentOrder(self, argListOriginal, parmList):
		argListNew = []
		
		for p in parmList:
			argListNew.append('placeholder') # junk values to size the list, allows indexing later
			
		# one-to-one mapping of arguments to parameters. (w/ no defaults)
		if ( len(parmList) == 1):
			 pTemp = parmList[0]
			 if (pTemp.lower() == 'onetoone'):
			 	return argListOriginal
			 		
		# reording arguments via reordering parameters	
		parmPosition = 0
		
		for p in parmList:
			letter = p[0]
			restOfParm = p[1:]  # could be a number or a string
			
			nextArg = ''		
			if letter == 'p':
				nextArg = argListOriginal[string.atoi(restOfParm) - 1]
			elif letter == 'd':
				nextArg = restOfParm
			
			argListNew[parmPosition] = nextArg			
			parmPosition += 1		
		return argListNew
		
		
	# private utility function
	def makeArgumentString(self, argumentList):
		argumentString = ''
		firstArg = 1
		for a in argumentList:
			if (firstArg == 0):
				argumentString += ','
				
			argumentString += str(a)
			firstArg = 0

		return argumentString
		

	def getSuccessCriteriaString(self, apiName, ddtafCmd):	
		mapping = self.apiDB.getMapping(apiName, ddtafCmd)			
		return mapping.successCriteriaString
