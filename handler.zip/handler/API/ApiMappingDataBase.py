# Responsibility: holds mappings of DTAF commands to API calls (MS COM, etc.)

class ApiMapping:
    
    def __init__(self, apiName, ddtafCmd, successCriteriaString, apiCmd, numParms, parmListString):
        self.apiName = apiName   # ex. 'zApi'
        self.ddtafCmd = ddtafCmd  # ex. 'realtime'
        self.successCriteriaString = successCriteriaString #ex. '==True', or 'void'
        self.apiCmd = apiCmd  # ex 'RealTime'
        self.numParms = numParms # ex. 0, 1, 2, ...
        self.parmListString = parmListString # 'p1,p2,p4,p3,d5.1,p6'  p= paramater, d= defualt
    
    
#interface class for Api Mapping Data Bases
# Used to document intent. Interfaces are not really necessary in Python.
class ApiMappingDatabase:

    def addMapping(self, apiMapping):
        raise "Interface only. Shouldn't get here."
        
    def getMapping(self, apiName, ddtafCmd):
         raise "Interface only. Shouldn't get here."
         
    def isMapping(self, apiName, ddtafCmd):
         raise "Interface only. Shouldn't get here."
        
    def getMappingCount(self):
        raise "Interface only. Shouldn't get here."
        
    def getApiCount(self):
        raise "Interface only. Shouldn't get here."
        
    def getCount(self, apiName):
        raise "Interface only. Shouldn't get here."
        
        
class ApiMappingDatabaseForTest(ApiMappingDatabase):
    
    def __init__(self):
        self.apiMappings = []
 
    
    def addMapping(self, apiMapping):
        self.apiMappings.append(apiMapping)
    
        
    def getMapping(self, apiName, ddtafCmd):
        mapping = None
        
        for m in self.apiMappings:
            if ((m.apiName == apiName) and (m.ddtafCmd == ddtafCmd)):
                mapping = m
                break
        
        return mapping

        
    def getMappingCount(self):
        return len(self.apiMappings)
 
        
    def isMapping(self, apiName, ddtafCmd):
        mapping = self.getMapping(apiName, ddtafCmd)
        return (mapping != None)
 
        
    def getApiCount(self):
        apiSet = []
        for m in self.apiMappings:
            if (apiSet.count(m.apiName) == 0):
                apiSet.append(m.apiName)
                
        return len(apiSet)

        
    def getCount(self, apiName):
        count = 0
        for m in self.apiMappings:
            if (m.apiName == apiName):
                count += 1
                
        return count
            