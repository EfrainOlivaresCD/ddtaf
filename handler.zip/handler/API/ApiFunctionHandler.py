# DDTAF's ApiFunctionHandler

from core.TestStep import TestStep
from ApiMapper import *

#TODO: add from SilkTest_Handler import SilkTest_Handler 

class ApiFunctionHandler:  #TODO add (SilkTest_Handler):

    def __init__(self, apiMappingDataBase, apiGroup):
        self.executableString = 'raise "ERROR: no executableString available"'
        self.apiMappingDataBase = apiMappingDataBase
        
        self.apiGroup = apiGroup  # need to have various API objects in scope of exec calls
        
        
    def Handle_Command(self, command):
        try:
            if (command == None):
                return 'Error'
            
            apiName = command.getWindow()   
            ddtafCmd = self.getDdtafCmd(command)
            dataString = command.getData()        
            argumentList = self.makeArgumentList(dataString)
            
            apiMapper = ApiMapper(self.apiMappingDataBase)
        
            if ( False == apiMapper.isValidCommand(apiName, ddtafCmd, argumentList)):
                #print 'ApiFunctionHandler.Handle_Command invalid pTestStep'
                return 'Error'
            else:           
                self.executableString = self.buildExectutableString(apiMapper, self.apiGroup, apiName, ddtafCmd, dataString)
            
        except:
            print 'ERROR: ApiFunctionHandler.Handle_Command  exception caught.'
            return 'Error'
        
        return 'Ok'
    
    
    def Execute(self, command):
        if (command == None):
            return 'Fail'
                
        try:        
            self.Handle_Command(command) # TODO revisit. Possibly extract a method for sharing.
            
            #print "self.executableString: ", self.executableString
            executableString = 'result=' + self.executableString
            #print "executableString: ", executableString
            
            exec(executableString) # contains assignment to a 'success' variable

            if (success):
                return "Pass"
            else:
                print 'ERROR: ApiFunctionHandler.Execute  failed.' 
                print 'ERROR: ApiFunctionHandler.Execute testName: ' +  command.testName +  ' executableString: ' + executableString
                return "Fail"
        except:
            print 'ERROR: ApiFunctionHandler.Execute  exception caught.'
            return 'Fail'           
        
        # shouldn't get here
        return 'Fail' 
        

    def getDdtafCmd(self, command):            
        object = command.getItem('object').split('/')
        object0 = object[0]
        ddtafCmd = re.sub(' ', '', object0) 
        return ddtafCmd 
        
            
    def makeArgumentList(self, dataString): 
        argumentList = []
        
        dataString = re.sub(' ', '',dataString)
        
        if ( (dataString == '') or (dataString == 'void') ): 
            argumentList.append(dataString)
        else:
            argumentList = dataString.split(',')
            
        return argumentList
            
                        
    def buildExectutableString(self, apiMapper, apiGroup, apiName, ddtafCmd, dataString):
        
        executableString = 'self.apiGroup.' + apiMapper.getExecutableString(apiName, ddtafCmd, dataString)
        executableString += ';success=('
                    
        successCriteriaString = apiMapper.getSuccessCriteriaString(apiName, ddtafCmd)
           
        if ( successCriteriaString.lower() =='void')  or (successCriteriaString ==''):
            executableString +='True'          
        else:
            executableString += 'result'
            executableString += successCriteriaString
            
        executableString += ')' + ';command.setData(result)'
        
        return executableString