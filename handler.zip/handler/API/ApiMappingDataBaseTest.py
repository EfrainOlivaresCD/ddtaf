# tests for DDTAF's ApiMappingDatabase

from ApiMappingDataBase import *
import unittest

class ApiMappingDataBaseTest(unittest.TestCase):
    #def setUp(self): pass
    #def tearDown(self): pass    

    def testCreation(self):  ## test method names begin 'test*'
        apiDB = ApiMappingDatabaseForTest()
        self.assert_(1)


    def testAddMapping(self):
        apiDB = ApiMappingDatabaseForTest()
        self.assertEquals(0, apiDB.getMappingCount())
        self.assertEquals(0, apiDB.getApiCount())

        #def __init__(self, apiName, ddtafCmd, successCode, apiCmd, numParms, parmTypeList, parmDefaultList):
        apiMapping1 = ApiMapping('zApi', 'realtime', 'void', 'Realtime', 0, 'void')
        apiDB.addMapping( apiMapping1)
        self.assertEquals(1, apiDB.getMappingCount())
        self.assertEquals(1, apiDB.getApiCount())
        self.assertEquals(1, apiDB.getCount('zApi'))
        
        apiMapping2 = ApiMapping('Stage', 'movetoxy', '1', 'MoveToXY', 2, 'p1,p2')
        apiDB.addMapping( apiMapping2)
        self.assertEquals(2, apiDB.getMappingCount())
        self.assertEquals(2, apiDB.getApiCount())
        self.assertEquals(1, apiDB.getCount('Stage'))
        
        apiMapping3 = ApiMapping('zApi', 'realtime2', 'void', 'Realtime2', 0, 'void')
        apiDB.addMapping( apiMapping3)
        self.assertEquals(3, apiDB.getMappingCount())
        self.assertEquals(2, apiDB.getApiCount())
        self.assertEquals(2, apiDB.getCount('zApi'))
        self.assertEquals(1, apiDB.getCount('Stage'))


    def testGetMappingList(self):
        apiDB = ApiMappingDatabaseForTest()
        self.assertEquals(0, apiDB.getMappingCount())
        self.assertEquals(0, apiDB.getApiCount())

        #def __init__(self, apiName, ddtafCmd, successCode, apiCmd, numParms, parmTypeList, parmDefaultList):
        apiMapping1 = ApiMapping('zApi', 'realtime', 'void', 'Realtime', 0, 'void')
        apiDB.addMapping( apiMapping1)
        self.assertEquals(1, apiDB.getMappingCount())
        self.assertEquals(1, apiDB.getApiCount())
        self.assertEquals(1, apiDB.getCount('zApi'))
        
        storedMapping1 = apiDB.getMapping('zApi', 'realtime')    
        self.assertEquals(storedMapping1, apiMapping1)       
          
        apiMapping2 = ApiMapping('Stage', 'movetoxy', '1', 'MoveToXY', 2, 'p1,p2')
        apiDB.addMapping( apiMapping2)
        self.assertEquals(2, apiDB.getMappingCount())
        self.assertEquals(2, apiDB.getApiCount())
        self.assertEquals(1, apiDB.getCount('Stage'))
        
        storedMapping2 = apiDB.getMapping('Stage', 'movetoxy')    
        self.assertEquals(storedMapping2, apiMapping2)
        
        apiMapping3 = ApiMapping('zApi', 'realtime2', 'void', 'Realtime2', 0, 'void')
        apiDB.addMapping( apiMapping3)
        self.assertEquals(3, apiDB.getMappingCount())
        self.assertEquals(2, apiDB.getApiCount())
        self.assertEquals(2, apiDB.getCount('zApi'))
        self.assertEquals(1, apiDB.getCount('Stage'))

        storedMapping3 = apiDB.getMapping('zApi', 'realtime2')    
        self.assertEquals(storedMapping3, apiMapping3)

 
    def testGetMappingElements(self):
        apiDB = ApiMappingDatabaseForTest()

        #def __init__(self, apiName, ddtafCmd, successCode, apiCmd, numParms, parmTypeList, parmDefaultList):
        apiMapping = ApiMapping('zApi', 'realtime', 'void', 'RealTime', 0, 'void')
        apiDB.addMapping( apiMapping)
        
        storedMapping = apiDB.getMapping('zApi', 'realtime')    
        self.assertEquals(storedMapping, apiMapping)   
        
        self.assertEquals(storedMapping.apiCmd, 'RealTime')   
        self.assertEquals(storedMapping.numParms, 0)  
        self.assertEquals(storedMapping.parmListString, 'void')            
 
 
    def testIsMapping(self):
        apiDB = ApiMappingDatabaseForTest()

        #def __init__(self, apiName, ddtafCmd, successCode, apiCmd, numParms, parmTypeList, parmDefaultList):
        apiMapping = ApiMapping('zApi', 'realtime', 'void', 'RealTime', 0, 'void')
        apiDB.addMapping( apiMapping)
           
        self.assertEquals(True, apiDB.isMapping('zApi', 'realtime') )   
        self.assertEquals(False, apiDB.isMapping('junk', 'realtime') )  
            
          
############################################################################
        
if __name__ == '__main__':
    unittest.main()