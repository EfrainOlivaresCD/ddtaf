import re
import sys
import time
from win32com.client import Dispatch

from common import Singleton
from handler.Handler import Handler_Base
from interface.IHandler import IHandlerComponent

class ZAPI_Handler_Registry(IHandlerComponent):
    def __init__(self):
        self._dispatcher = None
    
    def start(self):
        #Register API handlers
        self._dispatcher.register_handler(StartNanoScope('startnanoscope'))
        self._dispatcher.register_handler(RealTime('realtime'))
        self._dispatcher.register_handler(GetScanSize('getscansize'))
        self._dispatcher.register_handler(IsEngaged('isengaged'))
    
        #Registers API Generic Handlers
        self._dispatcher.register_handler(HandlerForSetAction('set'))
        self._dispatcher.register_handler(HandlerForGetAction('get'))
        self._dispatcher.register_handler(HandlerForVerifyAction('verify'))
        self._dispatcher.register_handler(HandlerForExecuteAction('execute'))
        self._dispatcher.register_handler(HandlerForDoAction('do'))
    
    def setDispatcher(self, pDispatcher):
        self._dispatcher = pDispatcher        

class NanoScope(IHandlerComponent):
    __metaclass__ = Singleton.Singleton
    
    def __init__(self):
		self.z = 'NULL'
		self.Up = 'FALSE'

    def Start(self):
        print 'z = Dispatch("Nanoscope.zApi")'
        self.z = Dispatch("Nanoscope.zApi")
        self.Up = 'TRUE'    
    
    def IsUp(self):
        return self.Up

    def Z(self):
        return self.z

    # TODO consider moving this method. 
    def getValue(self, pTestStep):  
		try:
			window = pTestStep.getItem('window')
			#print 'Nanoscope getValue pTestStep.getWindow() = ', pTestStep.getWindow()
			object = pTestStep.getItem('object')
			object0 = object[0]
			object0String = re.sub(' ', '', object0)
			
			property = zApiMap[window][object0String] 

			expressionString = 'self.Z().' + property

			#print 'Nanoscope getValue expressionString: ', expressionString

			result = eval(expressionString)

			return result

		except:
			print 'ERROR in zApi Nanoscope getValue(). Exception caught. Show info and continue'
			(ErrorType, ErrorValue, ErrorTB) = sys.exc_info()
			print sys.exc_info()
			return 0

class CommonFunctions:
    def getDataValue(self, pTestStep):
        dataString = pTestStep.getItem('data')
        dataString = str(dataString)
        val = ''
    
        try:
            for c in dataString:
                if (c.isdigit() or c == '-' or c == '.'):
                    val += c
        except:
            print 'ERROR in CommonFunctions.getDataValue(). dataString: ', dataString
            (ErrorType, ErrorValue, ErrorTB) = sys.exc_info()
            print sys.exc_info()

        return eval(val)
        
class StartNanoScope(Handler_Base):
    def Execute(self, pTestStep):
        NanoScope().Start()
        print 'Starting NanoScope'
        return 'Pass'

#mapping of DDTAF Windows and Objects to zApi properties, of the form:
#map = {'window1':{'object1':'apiFunction1', 'object2':'apiFunction2'}}  
zApiMap = {
	'cantilevertune':
	{
		'startfrequency':'CantileverTuneStartFrequency',
		'endfrequency':'CantileverTuneEndFrequency',
		'targetamplitude':'CantileverTuneTargetAmplitude',
		'peakoffset':'CantileverTunePeakOffset',
		'minimumq':'CantileverTuneMinimumQ',
		'smashwidthfactor':'CantileverTuneSmashWidthFactor',
		'drivefrequency':'CantileverTuneDriveFrequency'
	}
}

class RealTime(Handler_Base):
    def Execute(self, pTestStep):
        if (NanoScope().IsUp() == 'TRUE'):
            print 'Starting Real Time'
            NanoScope().Z().RealTime()
            return 'Pass'
        return 'Fail'

class GetScanSize(Handler_Base):
    def Execute(self, pTestStep):
        if (NanoScope().IsUp() == 'TRUE'):
            print 'SUCCESS, WE GOT SCAN SIZE: ' + str(NanoScope().Z().GetScanSize())
            return 'Pass'
        return 'Fail'
    
class IsEngaged(Handler_Base):
    def Execute(self, pTestStep):
        if (NanoScope().IsUp() == 'TRUE'):
            print 'IsEngaged returned: ' + str(NanoScope().Z().IsEngaged())
            return 'Pass'
        return 'Fail'

class HandlerForSetAction(Handler_Base):
    def Execute(self, pTestStep):

		#print 'HandlerForSetAction called'

		if (NanoScope().IsUp() == 'TRUE'):
			try:
				#print 'HandlerForSetAction inside handler'
				window = pTestStep.getItem('window')
				#print 'HandlerForSetAction pTestStep.getWindow() = ', pTestStep.getWindow()
				object = pTestStep.getItem('object')
				object0 = object[0]
				object0String = re.sub(' ', '', object0)
				
				property = zApiMap[window][object0String] 

				expressionString = 'NanoScope().Z().' + property + ' = ' + str(CommonFunctions().getDataValue(pTestStep))

				#print 'HandlerForSetAction expressionString: ', expressionString

				exec expressionString

				return 'Pass'
			except:
				print 'ERROR in zApi HandlerForSetAction(). Exception caught. Show info and continue'
				(ErrorType, ErrorValue, ErrorTB) = sys.exc_info()
				print sys.exc_info()

		return 'Fail'


class HandlerForGetAction(Handler_Base):
    def Execute(self, pTestStep):
		#print 'HandlerForGetAction called'

		if (NanoScope().IsUp() == 'TRUE'):
			try:
				#print 'HandlerForGetAction inside handler'

				result = NanoScope().getValue(pTestStep)

				pTestStep.setItem('data',result)

				return 'Pass'
			except:
				print 'ERROR in zApi HandlerForGetAction(). Exception caught. Show info and continue'
				(ErrorType, ErrorValue, ErrorTB) = sys.exc_info()
				print sys.exc_info()

		return 'Fail'


class HandlerForVerifyAction(Handler_Base):
    def Execute(self, pTestStep):
        if (NanoScope().IsUp() == 'TRUE'):
			try:
				#print 'HandlerForVerifyAction inside handler'

				result = NanoScope().getValue(pTestStep)

				expectedResult = CommonFunctions().getDataValue(pTestStep)

				if (result == expectedResult):
					return 'Pass'
				else:
					print 'Failure in HandlerForVerifyAction. Result: ', result
					print 'Expected Result: ', expectedResult
					return 'Fail'

			except:
				print 'ERROR in zApi HandlerForVerfiyAction(). Exception caught. Show info and continue'
				(ErrorType, ErrorValue, ErrorTB) = sys.exc_info()
				print sys.exc_info()

        return 'Fail'


class HandlerForExecuteAction(Handler_Base):
    def Execute(self, pTestStep):
        if (NanoScope().IsUp() == 'TRUE'):
			try:
				#print 'HandlerForExecuteAction inside handler'
				window = pTestStep.getItem('window')
				#print 'HandlerForExecuteAction pTestStep.getWindow() = ', pTestStep.getWindow()
				object = pTestStep.getItem('object')
				object0 = object[0]
				object0String = re.sub(' ', '', object0)

				if (object0String == 'autotune'):
					#print 'HandlerForExecuteAction autotune case'
					NanoScope().Z().StartAutoCantileverTune()

					#print 'HandlerForExecuteAction autotune case pre wait for done'
					while (NanoScope().Z().IsAutoCantileverTuneDone() != 1):
						time.sleep(0.5)

					return 'Pass'

				elif (object0String == 'istunegood'):
					#print 'HandlerForExecuteAction istunegood case'
					if ( NanoScope().Z().IsTuneGood(0.80) == 1):
						return 'Pass'
					else:
						return 'Fail'

				elif (object0String == 'savetunedata'):
					#print 'HandlerForExecuteAction istunegood case'
					file = pTestStep.getItem('data')
					file = re.sub('\"', '', file)
					#print 'HandlerForExecuteAction istunegood case file ', file
					NanoScope().Z().CantileverTuneSaveTuneData(file)
					return 'Pass'

				else:
					print 'ERROR: TODO: HandlerForExecuteAction does not yet implement ', object0String 

			except:
				print 'ERROR in zApi HandlerForExecuteAction(). Exception caught. Show info and continue'
				(ErrorType, ErrorValue, ErrorTB) = sys.exc_info()
				print sys.exc_info()

        return 'Fail'

class HandlerForDoAction(Handler_Base):
    def Execute(self, pTestStep):
        if (NanoScope().IsUp() == 'TRUE'):
			print 'HandlerForDoAction not implemented yet. Use Execute until all tests switched.'
			return 'Fail'   # for now

			#return 'Pass'
        return 'Fail'
