from interface import IFactory
from handler.API import ApiFunctionHandler
from handler.SilkTest import SilkTest_Handler
from handler.python import Python_Handler
from handler.ZAPI import zapi
from handler.ETF import ETFHandler
from handler.SimFW import SimFWHandler

class HandlerFactory(IFactory.IFactory):
    def __init__(self):
        self._dispatcher = None
        
    def setDispatcher(self, pDispatcher):
        self._dispatcher = pDispatcher
        
    def create(self, pName, pParamDict):
        # these COM server threads are used for the port 
        # object the simulators connect to
        comp = None
        #if pName == "API":
        #    comp =ApiFunctionHandler.ApiFunctionHandler()
        if pName == "command":
            comp = SilkTest_Handler.SilkTest_Handler_Registry()
        if pName == "python":
            comp = Python_Handler.Python_Handler_Registry()
        if pName == "zapi":
            comp = zapi.ZAPI_Handler_Registry()
        if pName == "etf":
            comp = ETFHandler.ETF_Handler_Registry()
        if pName == "simfw":
            comp = SimFWHandler.SimFW_Handler_Registry()
        if comp == None:
            #TODO: display error that component could not be loaded
            pass
        else:
            comp.setDispatcher(self._dispatcher)
        return comp